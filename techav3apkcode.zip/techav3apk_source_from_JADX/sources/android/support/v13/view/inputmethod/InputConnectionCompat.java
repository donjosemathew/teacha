package android.support.v13.view.inputmethod;

import android.content.ClipDescription;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputContentInfo;

public final class InputConnectionCompat {
    private static final String COMMIT_CONTENT_ACTION = "android.support.v13.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
    private static final String COMMIT_CONTENT_CONTENT_URI_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_URI";
    private static final String COMMIT_CONTENT_DESCRIPTION_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
    private static final String COMMIT_CONTENT_FLAGS_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
    private static final String COMMIT_CONTENT_LINK_URI_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
    private static final String COMMIT_CONTENT_OPTS_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
    private static final String COMMIT_CONTENT_RESULT_RECEIVER = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
    public static final int INPUT_CONTENT_GRANT_READ_URI_PERMISSION = 1;

    public interface OnCommitContentListener {
        boolean onCommitContent(InputContentInfoCompat inputContentInfoCompat, int i, Bundle bundle);
    }

    /* JADX INFO: finally extract failed */
    static boolean handlePerformPrivateCommand(@Nullable String str, @NonNull Bundle bundle, @NonNull OnCommitContentListener onCommitContentListener) {
        InputContentInfoCompat inputContentInfoCompat;
        Bundle data = bundle;
        OnCommitContentListener onCommitContentListener2 = onCommitContentListener;
        if (!TextUtils.equals(COMMIT_CONTENT_ACTION, str)) {
            return false;
        }
        if (data == null) {
            return false;
        }
        ResultReceiver resultReceiver = null;
        try {
            resultReceiver = (ResultReceiver) data.getParcelable(COMMIT_CONTENT_RESULT_RECEIVER);
            Uri contentUri = (Uri) data.getParcelable(COMMIT_CONTENT_CONTENT_URI_KEY);
            ClipDescription description = (ClipDescription) data.getParcelable(COMMIT_CONTENT_DESCRIPTION_KEY);
            Uri linkUri = (Uri) data.getParcelable(COMMIT_CONTENT_LINK_URI_KEY);
            int flags = data.getInt(COMMIT_CONTENT_FLAGS_KEY);
            Bundle opts = (Bundle) data.getParcelable(COMMIT_CONTENT_OPTS_KEY);
            InputContentInfoCompat inputContentInfoCompat2 = inputContentInfoCompat;
            InputContentInfoCompat inputContentInfoCompat3 = new InputContentInfoCompat(contentUri, description, linkUri);
            boolean result = onCommitContentListener2.onCommitContent(inputContentInfoCompat2, flags, opts);
            if (resultReceiver != null) {
                resultReceiver.send(result ? 1 : 0, null);
            }
            return result;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (resultReceiver != null) {
                resultReceiver.send(0 != 0 ? 1 : 0, null);
            }
            throw th2;
        }
    }

    public static boolean commitContent(@NonNull InputConnection inputConnection, @NonNull EditorInfo editorInfo, @NonNull InputContentInfoCompat inputContentInfoCompat, int i, @Nullable Bundle bundle) {
        Bundle bundle2;
        InputConnection inputConnection2 = inputConnection;
        EditorInfo editorInfo2 = editorInfo;
        InputContentInfoCompat inputContentInfo = inputContentInfoCompat;
        int flags = i;
        Bundle opts = bundle;
        ClipDescription description = inputContentInfo.getDescription();
        boolean supported = false;
        String[] contentMimeTypes = EditorInfoCompat.getContentMimeTypes(editorInfo2);
        int length = contentMimeTypes.length;
        int i2 = 0;
        while (true) {
            if (i2 >= length) {
                break;
            }
            if (description.hasMimeType(contentMimeTypes[i2])) {
                supported = true;
                break;
            }
            i2++;
        }
        if (!supported) {
            return false;
        }
        if (VERSION.SDK_INT >= 25) {
            return inputConnection2.commitContent((InputContentInfo) inputContentInfo.unwrap(), flags, opts);
        }
        Bundle bundle3 = bundle2;
        Bundle bundle4 = new Bundle();
        Bundle params = bundle3;
        params.putParcelable(COMMIT_CONTENT_CONTENT_URI_KEY, inputContentInfo.getContentUri());
        params.putParcelable(COMMIT_CONTENT_DESCRIPTION_KEY, inputContentInfo.getDescription());
        params.putParcelable(COMMIT_CONTENT_LINK_URI_KEY, inputContentInfo.getLinkUri());
        params.putInt(COMMIT_CONTENT_FLAGS_KEY, flags);
        params.putParcelable(COMMIT_CONTENT_OPTS_KEY, opts);
        return inputConnection2.performPrivateCommand(COMMIT_CONTENT_ACTION, params);
    }

    @NonNull
    public static InputConnection createWrapper(@NonNull InputConnection inputConnection, @NonNull EditorInfo editorInfo, @NonNull OnCommitContentListener onCommitContentListener) {
        C02332 r10;
        C02321 r102;
        IllegalArgumentException illegalArgumentException;
        IllegalArgumentException illegalArgumentException2;
        IllegalArgumentException illegalArgumentException3;
        InputConnection inputConnection2 = inputConnection;
        EditorInfo editorInfo2 = editorInfo;
        OnCommitContentListener onCommitContentListener2 = onCommitContentListener;
        if (inputConnection2 == null) {
            IllegalArgumentException illegalArgumentException4 = illegalArgumentException3;
            IllegalArgumentException illegalArgumentException5 = new IllegalArgumentException("inputConnection must be non-null");
            throw illegalArgumentException4;
        } else if (editorInfo2 == null) {
            IllegalArgumentException illegalArgumentException6 = illegalArgumentException2;
            IllegalArgumentException illegalArgumentException7 = new IllegalArgumentException("editorInfo must be non-null");
            throw illegalArgumentException6;
        } else if (onCommitContentListener2 == null) {
            IllegalArgumentException illegalArgumentException8 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException9 = new IllegalArgumentException("onCommitContentListener must be non-null");
            throw illegalArgumentException8;
        } else if (VERSION.SDK_INT >= 25) {
            InputConnection inputConnection3 = r102;
            final OnCommitContentListener onCommitContentListener3 = onCommitContentListener2;
            C02321 r6 = new InputConnectionWrapper(inputConnection2, false) {
                {
                    InputConnection x0 = r8;
                    boolean x1 = r9;
                }

                public boolean commitContent(InputContentInfo inputContentInfo, int i, Bundle bundle) {
                    InputContentInfo inputContentInfo2 = inputContentInfo;
                    int flags = i;
                    Bundle opts = bundle;
                    if (onCommitContentListener3.onCommitContent(InputContentInfoCompat.wrap(inputContentInfo2), flags, opts)) {
                        return true;
                    }
                    return super.commitContent(inputContentInfo2, flags, opts);
                }
            };
            return inputConnection3;
        } else if (EditorInfoCompat.getContentMimeTypes(editorInfo2).length == 0) {
            return inputConnection2;
        } else {
            InputConnection inputConnection4 = r10;
            final OnCommitContentListener onCommitContentListener4 = onCommitContentListener2;
            C02332 r62 = new InputConnectionWrapper(inputConnection2, false) {
                {
                    InputConnection x0 = r8;
                    boolean x1 = r9;
                }

                public boolean performPrivateCommand(String str, Bundle bundle) {
                    String action = str;
                    Bundle data = bundle;
                    if (InputConnectionCompat.handlePerformPrivateCommand(action, data, onCommitContentListener4)) {
                        return true;
                    }
                    return super.performPrivateCommand(action, data);
                }
            };
            return inputConnection4;
        }
    }

    @Deprecated
    public InputConnectionCompat() {
    }
}
