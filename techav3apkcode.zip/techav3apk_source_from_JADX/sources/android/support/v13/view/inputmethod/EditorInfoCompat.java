package android.support.v13.view.inputmethod;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.inputmethod.EditorInfo;

public final class EditorInfoCompat {
    private static final String CONTENT_MIME_TYPES_KEY = "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES";
    private static final String[] EMPTY_STRING_ARRAY = new String[0];
    public static final int IME_FLAG_FORCE_ASCII = Integer.MIN_VALUE;
    public static final int IME_FLAG_NO_PERSONALIZED_LEARNING = 16777216;

    public static void setContentMimeTypes(@NonNull EditorInfo editorInfo, @Nullable String[] strArr) {
        Bundle bundle;
        EditorInfo editorInfo2 = editorInfo;
        String[] contentMimeTypes = strArr;
        if (VERSION.SDK_INT >= 25) {
            editorInfo2.contentMimeTypes = contentMimeTypes;
            return;
        }
        if (editorInfo2.extras == null) {
            EditorInfo editorInfo3 = editorInfo2;
            Bundle bundle2 = bundle;
            Bundle bundle3 = new Bundle();
            editorInfo3.extras = bundle2;
        }
        editorInfo2.extras.putStringArray(CONTENT_MIME_TYPES_KEY, contentMimeTypes);
    }

    @NonNull
    public static String[] getContentMimeTypes(EditorInfo editorInfo) {
        EditorInfo editorInfo2 = editorInfo;
        if (VERSION.SDK_INT >= 25) {
            String[] result = editorInfo2.contentMimeTypes;
            return result != null ? result : EMPTY_STRING_ARRAY;
        } else if (editorInfo2.extras == null) {
            return EMPTY_STRING_ARRAY;
        } else {
            String[] result2 = editorInfo2.extras.getStringArray(CONTENT_MIME_TYPES_KEY);
            return result2 != null ? result2 : EMPTY_STRING_ARRAY;
        }
    }

    @Deprecated
    public EditorInfoCompat() {
    }
}
