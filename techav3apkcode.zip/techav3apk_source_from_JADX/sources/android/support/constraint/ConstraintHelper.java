package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.constraint.C0025R.C0026id;
import android.support.constraint.solver.widgets.Helper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import java.util.Arrays;

public abstract class ConstraintHelper extends View {
    protected int mCount;
    protected Helper mHelperWidget;
    protected int[] mIds = new int[32];
    private String mReferenceIds;
    protected boolean mUseViewMeasure = false;
    protected Context myContext;

    public ConstraintHelper(Context context) {
        Context context2 = context;
        super(context2);
        this.myContext = context2;
        init(null);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        Context context2 = context;
        AttributeSet attrs = attributeSet;
        super(context2, attrs);
        this.myContext = context2;
        init(attrs);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i) {
        Context context2 = context;
        AttributeSet attrs = attributeSet;
        super(context2, attrs, i);
        this.myContext = context2;
        init(attrs);
    }

    /* access modifiers changed from: protected */
    public void init(AttributeSet attributeSet) {
        AttributeSet attrs = attributeSet;
        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs, C0025R.styleable.ConstraintLayout_Layout);
            int N = a.getIndexCount();
            for (int i = 0; i < N; i++) {
                int attr = a.getIndex(i);
                if (attr == C0025R.styleable.ConstraintLayout_Layout_constraint_referenced_ids) {
                    this.mReferenceIds = a.getString(attr);
                    setIds(this.mReferenceIds);
                }
            }
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.mIds, this.mCount);
    }

    public void setReferencedIds(int[] iArr) {
        int[] ids = iArr;
        this.mCount = 0;
        for (int i = 0; i < ids.length; i++) {
            setTag(ids[i], null);
        }
    }

    public void setTag(int i, Object obj) {
        int tag = i;
        Object obj2 = obj;
        if (this.mCount + 1 > this.mIds.length) {
            this.mIds = Arrays.copyOf(this.mIds, this.mIds.length * 2);
        }
        this.mIds[this.mCount] = tag;
        this.mCount++;
    }

    public void onDraw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int widthMeasureSpec = i;
        int heightMeasureSpec = i2;
        if (this.mUseViewMeasure) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void validateParams() {
        if (this.mHelperWidget != null) {
            LayoutParams params = getLayoutParams();
            if (params instanceof ConstraintLayout.LayoutParams) {
                ((ConstraintLayout.LayoutParams) params).widget = this.mHelperWidget;
            }
        }
    }

    private void addID(String str) {
        StringBuilder sb;
        String idString = str;
        if (idString != null && this.myContext != null) {
            String idString2 = idString.trim();
            int tag = 0;
            try {
                tag = C0026id.class.getField(idString2).getInt(null);
            } catch (Exception e) {
                Exception exc = e;
            }
            if (tag == 0) {
                tag = this.myContext.getResources().getIdentifier(idString2, "id", this.myContext.getPackageName());
            }
            if (tag == 0 && isInEditMode() && (getParent() instanceof ConstraintLayout)) {
                Object value = ((ConstraintLayout) getParent()).getDesignInformation(0, idString2);
                if (value != null && (value instanceof Integer)) {
                    tag = ((Integer) value).intValue();
                }
            }
            if (tag != 0) {
                setTag(tag, null);
                return;
            }
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            int w = Log.w("ConstraintHelper", sb2.append("Could not find id of \"").append(idString2).append("\"").toString());
        }
    }

    private void setIds(String str) {
        String idList = str;
        if (idList != null) {
            int i = 0;
            while (true) {
                int begin = i;
                int end = idList.indexOf(44, begin);
                if (end == -1) {
                    addID(idList.substring(begin));
                    return;
                } else {
                    addID(idList.substring(begin, end));
                    i = end + 1;
                }
            }
        }
    }

    public void updatePreLayout(ConstraintLayout constraintLayout) {
        ConstraintLayout container = constraintLayout;
        if (isInEditMode()) {
            setIds(this.mReferenceIds);
        }
        if (this.mHelperWidget != null) {
            this.mHelperWidget.removeAllIds();
            for (int i = 0; i < this.mCount; i++) {
                View view = container.getViewById(this.mIds[i]);
                if (view != null) {
                    this.mHelperWidget.add(container.getViewWidget(view));
                }
            }
        }
    }

    public void updatePostLayout(ConstraintLayout container) {
    }

    public void updatePostMeasure(ConstraintLayout container) {
    }
}
