package android.support.constraint.solver;

import java.util.Arrays;

public class SolverVariable {
    private static final boolean INTERNAL_DEBUG = false;
    static final int MAX_STRENGTH = 7;
    public static final int STRENGTH_BARRIER = 7;
    public static final int STRENGTH_EQUALITY = 5;
    public static final int STRENGTH_FIXED = 6;
    public static final int STRENGTH_HIGH = 3;
    public static final int STRENGTH_HIGHEST = 4;
    public static final int STRENGTH_LOW = 1;
    public static final int STRENGTH_MEDIUM = 2;
    public static final int STRENGTH_NONE = 0;
    private static int uniqueConstantId = 1;
    private static int uniqueErrorId = 1;
    private static int uniqueId = 1;
    private static int uniqueSlackId = 1;
    private static int uniqueUnrestrictedId = 1;
    public float computedValue;
    int definitionId = -1;

    /* renamed from: id */
    public int f3id = -1;
    ArrayRow[] mClientEquations = new ArrayRow[8];
    int mClientEquationsCount = 0;
    private String mName;
    Type mType;
    public int strength = 0;
    float[] strengthVector = new float[7];
    public int usageInRowCount = 0;

    public enum Type {
    }

    static void increaseErrorId() {
        uniqueErrorId++;
    }

    private static String getUniqueName(Type type, String str) {
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        StringBuilder sb4;
        StringBuilder sb5;
        AssertionError assertionError;
        StringBuilder sb6;
        Type type2 = type;
        String prefix = str;
        if (prefix != null) {
            StringBuilder sb7 = sb6;
            StringBuilder sb8 = new StringBuilder();
            return sb7.append(prefix).append(uniqueErrorId).toString();
        }
        switch (type2) {
            case UNRESTRICTED:
                StringBuilder sb9 = sb5;
                StringBuilder sb10 = new StringBuilder();
                StringBuilder append = sb9.append("U");
                int i = uniqueUnrestrictedId + 1;
                int i2 = i;
                uniqueUnrestrictedId = i;
                return append.append(i2).toString();
            case CONSTANT:
                StringBuilder sb11 = sb4;
                StringBuilder sb12 = new StringBuilder();
                StringBuilder append2 = sb11.append("C");
                int i3 = uniqueConstantId + 1;
                int i4 = i3;
                uniqueConstantId = i3;
                return append2.append(i4).toString();
            case SLACK:
                StringBuilder sb13 = sb3;
                StringBuilder sb14 = new StringBuilder();
                StringBuilder append3 = sb13.append("S");
                int i5 = uniqueSlackId + 1;
                int i6 = i5;
                uniqueSlackId = i5;
                return append3.append(i6).toString();
            case ERROR:
                StringBuilder sb15 = sb2;
                StringBuilder sb16 = new StringBuilder();
                StringBuilder append4 = sb15.append("e");
                int i7 = uniqueErrorId + 1;
                int i8 = i7;
                uniqueErrorId = i7;
                return append4.append(i8).toString();
            case UNKNOWN:
                StringBuilder sb17 = sb;
                StringBuilder sb18 = new StringBuilder();
                StringBuilder append5 = sb17.append("V");
                int i9 = uniqueId + 1;
                int i10 = i9;
                uniqueId = i9;
                return append5.append(i10).toString();
            default:
                AssertionError assertionError2 = assertionError;
                AssertionError assertionError3 = new AssertionError(type2.name());
                throw assertionError2;
        }
    }

    public SolverVariable(String str, Type type) {
        String name = str;
        Type type2 = type;
        this.mName = name;
        this.mType = type2;
    }

    public SolverVariable(Type type, String str) {
        Type type2 = type;
        String str2 = str;
        this.mType = type2;
    }

    /* access modifiers changed from: 0000 */
    public void clearStrengths() {
        for (int i = 0; i < 7; i++) {
            this.strengthVector[i] = 0.0f;
        }
    }

    /* access modifiers changed from: 0000 */
    public String strengthsToString() {
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        StringBuilder sb4;
        StringBuilder sb5;
        String sb6;
        StringBuilder sb7;
        StringBuilder sb8 = sb;
        StringBuilder sb9 = new StringBuilder();
        String representation = sb8.append(this).append("[").toString();
        boolean negative = false;
        boolean empty = true;
        for (int j = 0; j < this.strengthVector.length; j++) {
            StringBuilder sb10 = sb4;
            StringBuilder sb11 = new StringBuilder();
            String representation2 = sb10.append(representation).append(this.strengthVector[j]).toString();
            if (this.strengthVector[j] > 0.0f) {
                negative = false;
            } else if (this.strengthVector[j] < 0.0f) {
                negative = true;
            }
            if (this.strengthVector[j] != 0.0f) {
                empty = false;
            }
            if (j < this.strengthVector.length - 1) {
                StringBuilder sb12 = sb7;
                StringBuilder sb13 = new StringBuilder();
                sb6 = sb12.append(representation2).append(", ").toString();
            } else {
                StringBuilder sb14 = sb5;
                StringBuilder sb15 = new StringBuilder();
                sb6 = sb14.append(representation2).append("] ").toString();
            }
            representation = sb6;
        }
        if (negative) {
            StringBuilder sb16 = sb3;
            StringBuilder sb17 = new StringBuilder();
            representation = sb16.append(representation).append(" (-)").toString();
        }
        if (empty) {
            StringBuilder sb18 = sb2;
            StringBuilder sb19 = new StringBuilder();
            representation = sb18.append(representation).append(" (*)").toString();
        }
        return representation;
    }

    public final void addToRow(ArrayRow arrayRow) {
        ArrayRow row = arrayRow;
        int i = 0;
        while (i < this.mClientEquationsCount) {
            if (this.mClientEquations[i] != row) {
                i++;
            } else {
                return;
            }
        }
        if (this.mClientEquationsCount >= this.mClientEquations.length) {
            this.mClientEquations = (ArrayRow[]) Arrays.copyOf(this.mClientEquations, this.mClientEquations.length * 2);
        }
        this.mClientEquations[this.mClientEquationsCount] = row;
        this.mClientEquationsCount++;
    }

    public final void removeFromRow(ArrayRow arrayRow) {
        ArrayRow row = arrayRow;
        int count = this.mClientEquationsCount;
        for (int i = 0; i < count; i++) {
            if (this.mClientEquations[i] == row) {
                for (int j = 0; j < (count - i) - 1; j++) {
                    this.mClientEquations[i + j] = this.mClientEquations[i + j + 1];
                }
                this.mClientEquationsCount--;
                return;
            }
        }
    }

    public final void updateReferencesWithNewDefinition(ArrayRow arrayRow) {
        ArrayRow definition = arrayRow;
        int count = this.mClientEquationsCount;
        for (int i = 0; i < count; i++) {
            this.mClientEquations[i].variables.updateFromRow(this.mClientEquations[i], definition, false);
        }
        this.mClientEquationsCount = 0;
    }

    public void reset() {
        this.mName = null;
        this.mType = Type.UNKNOWN;
        this.strength = 0;
        this.f3id = -1;
        this.definitionId = -1;
        this.computedValue = 0.0f;
        this.mClientEquationsCount = 0;
        this.usageInRowCount = 0;
    }

    public String getName() {
        return this.mName;
    }

    public void setName(String str) {
        String str2 = str;
        this.mName = str2;
    }

    public void setType(Type type, String str) {
        String str2 = str;
        Type type2 = type;
        this.mType = type2;
    }

    public String toString() {
        StringBuilder sb;
        String result = "";
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return sb2.append(result).append(this.mName).toString();
    }
}
