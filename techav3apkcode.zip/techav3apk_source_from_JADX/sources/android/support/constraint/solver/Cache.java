package android.support.constraint.solver;

public class Cache {
    Pool<ArrayRow> arrayRowPool;
    SolverVariable[] mIndexedVariables = new SolverVariable[32];
    Pool<SolverVariable> solverVariablePool;

    public Cache() {
        SimplePool simplePool;
        SimplePool simplePool2;
        SimplePool simplePool3 = simplePool;
        SimplePool simplePool4 = new SimplePool(256);
        this.arrayRowPool = simplePool3;
        SimplePool simplePool5 = simplePool2;
        SimplePool simplePool6 = new SimplePool(256);
        this.solverVariablePool = simplePool5;
    }
}
