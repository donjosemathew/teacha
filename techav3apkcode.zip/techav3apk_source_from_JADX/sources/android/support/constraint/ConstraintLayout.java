package android.support.constraint;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build.VERSION;
import android.support.constraint.solver.Metrics;
import android.support.constraint.solver.widgets.Analyzer;
import android.support.constraint.solver.widgets.ConstraintAnchor.Type;
import android.support.constraint.solver.widgets.ConstraintWidget;
import android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour;
import android.support.constraint.solver.widgets.ConstraintWidgetContainer;
import android.support.constraint.solver.widgets.Guideline;
import android.support.constraint.solver.widgets.ResolutionAnchor;
import android.support.p000v4.internal.view.SupportMenu;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import gnu.expr.Declaration;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
    static final boolean ALLOWS_EMBEDDED = false;
    private static final boolean CACHE_MEASURED_DIMENSION = false;
    private static final boolean DEBUG = false;
    public static final int DESIGN_INFO_ID = 0;
    private static final String TAG = "ConstraintLayout";
    private static final boolean USE_CONSTRAINTS_HELPER = true;
    public static final String VERSION = "ConstraintLayout-1.1.3";
    SparseArray<View> mChildrenByIds;
    private ArrayList<ConstraintHelper> mConstraintHelpers;
    private ConstraintSet mConstraintSet = null;
    private int mConstraintSetId = -1;
    private HashMap<String, Integer> mDesignIds;
    private boolean mDirtyHierarchy = true;
    private int mLastMeasureHeight;
    int mLastMeasureHeightMode;
    int mLastMeasureHeightSize;
    private int mLastMeasureWidth;
    int mLastMeasureWidthMode;
    int mLastMeasureWidthSize;
    ConstraintWidgetContainer mLayoutWidget;
    private int mMaxHeight = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    private int mMaxWidth = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    private Metrics mMetrics;
    private int mMinHeight = 0;
    private int mMinWidth = 0;
    private int mOptimizationLevel = 7;
    private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets;

    public static class LayoutParams extends MarginLayoutParams {
        public static final int BASELINE = 5;
        public static final int BOTTOM = 4;
        public static final int CHAIN_PACKED = 2;
        public static final int CHAIN_SPREAD = 0;
        public static final int CHAIN_SPREAD_INSIDE = 1;
        public static final int END = 7;
        public static final int HORIZONTAL = 0;
        public static final int LEFT = 1;
        public static final int MATCH_CONSTRAINT = 0;
        public static final int MATCH_CONSTRAINT_PERCENT = 2;
        public static final int MATCH_CONSTRAINT_SPREAD = 0;
        public static final int MATCH_CONSTRAINT_WRAP = 1;
        public static final int PARENT_ID = 0;
        public static final int RIGHT = 2;
        public static final int START = 6;
        public static final int TOP = 3;
        public static final int UNSET = -1;
        public static final int VERTICAL = 1;
        public int baselineToBaseline = -1;
        public int bottomToBottom = -1;
        public int bottomToTop = -1;
        public float circleAngle = 0.0f;
        public int circleConstraint = -1;
        public int circleRadius = 0;
        public boolean constrainedHeight = false;
        public boolean constrainedWidth = false;
        public String dimensionRatio = null;
        int dimensionRatioSide = 1;
        float dimensionRatioValue = 0.0f;
        public int editorAbsoluteX = -1;
        public int editorAbsoluteY = -1;
        public int endToEnd = -1;
        public int endToStart = -1;
        public int goneBottomMargin = -1;
        public int goneEndMargin = -1;
        public int goneLeftMargin = -1;
        public int goneRightMargin = -1;
        public int goneStartMargin = -1;
        public int goneTopMargin = -1;
        public int guideBegin = -1;
        public int guideEnd = -1;
        public float guidePercent = -1.0f;
        public boolean helped;
        public float horizontalBias = 0.5f;
        public int horizontalChainStyle = 0;
        boolean horizontalDimensionFixed = true;
        public float horizontalWeight = -1.0f;
        boolean isGuideline = false;
        boolean isHelper = false;
        boolean isInPlaceholder = false;
        public int leftToLeft = -1;
        public int leftToRight = -1;
        public int matchConstraintDefaultHeight = 0;
        public int matchConstraintDefaultWidth = 0;
        public int matchConstraintMaxHeight = 0;
        public int matchConstraintMaxWidth = 0;
        public int matchConstraintMinHeight = 0;
        public int matchConstraintMinWidth = 0;
        public float matchConstraintPercentHeight = 1.0f;
        public float matchConstraintPercentWidth = 1.0f;
        boolean needsBaseline = false;
        public int orientation = -1;
        int resolveGoneLeftMargin = -1;
        int resolveGoneRightMargin = -1;
        int resolvedGuideBegin;
        int resolvedGuideEnd;
        float resolvedGuidePercent;
        float resolvedHorizontalBias = 0.5f;
        int resolvedLeftToLeft = -1;
        int resolvedLeftToRight = -1;
        int resolvedRightToLeft = -1;
        int resolvedRightToRight = -1;
        public int rightToLeft = -1;
        public int rightToRight = -1;
        public int startToEnd = -1;
        public int startToStart = -1;
        public int topToBottom = -1;
        public int topToTop = -1;
        public float verticalBias = 0.5f;
        public int verticalChainStyle = 0;
        boolean verticalDimensionFixed = true;
        public float verticalWeight = -1.0f;
        ConstraintWidget widget;

        private static class Table {
            public static final int ANDROID_ORIENTATION = 1;
            public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
            public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
            public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
            public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
            public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
            public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
            public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
            public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
            public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
            public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
            public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
            public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
            public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
            public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
            public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
            public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
            public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
            public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
            public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
            public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
            public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
            public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
            public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
            public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
            public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
            public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
            public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
            public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
            public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
            public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
            public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
            public static final int LAYOUT_GONE_MARGIN_END = 26;
            public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
            public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
            public static final int LAYOUT_GONE_MARGIN_START = 25;
            public static final int LAYOUT_GONE_MARGIN_TOP = 22;
            public static final int UNUSED = 0;
            public static final SparseIntArray map;

            private Table() {
            }

            static {
                SparseIntArray sparseIntArray;
                SparseIntArray sparseIntArray2 = sparseIntArray;
                SparseIntArray sparseIntArray3 = new SparseIntArray();
                map = sparseIntArray2;
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
                map.append(C0025R.styleable.ConstraintLayout_Layout_android_orientation, 1);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
                map.append(C0025R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
            }
        }

        public void reset() {
            if (this.widget != null) {
                this.widget.reset();
            }
        }

        public LayoutParams(LayoutParams layoutParams) {
            ConstraintWidget constraintWidget;
            LayoutParams source = layoutParams;
            super(source);
            ConstraintWidget constraintWidget2 = constraintWidget;
            ConstraintWidget constraintWidget3 = new ConstraintWidget();
            this.widget = constraintWidget2;
            this.helped = false;
            this.guideBegin = source.guideBegin;
            this.guideEnd = source.guideEnd;
            this.guidePercent = source.guidePercent;
            this.leftToLeft = source.leftToLeft;
            this.leftToRight = source.leftToRight;
            this.rightToLeft = source.rightToLeft;
            this.rightToRight = source.rightToRight;
            this.topToTop = source.topToTop;
            this.topToBottom = source.topToBottom;
            this.bottomToTop = source.bottomToTop;
            this.bottomToBottom = source.bottomToBottom;
            this.baselineToBaseline = source.baselineToBaseline;
            this.circleConstraint = source.circleConstraint;
            this.circleRadius = source.circleRadius;
            this.circleAngle = source.circleAngle;
            this.startToEnd = source.startToEnd;
            this.startToStart = source.startToStart;
            this.endToStart = source.endToStart;
            this.endToEnd = source.endToEnd;
            this.goneLeftMargin = source.goneLeftMargin;
            this.goneTopMargin = source.goneTopMargin;
            this.goneRightMargin = source.goneRightMargin;
            this.goneBottomMargin = source.goneBottomMargin;
            this.goneStartMargin = source.goneStartMargin;
            this.goneEndMargin = source.goneEndMargin;
            this.horizontalBias = source.horizontalBias;
            this.verticalBias = source.verticalBias;
            this.dimensionRatio = source.dimensionRatio;
            this.dimensionRatioValue = source.dimensionRatioValue;
            this.dimensionRatioSide = source.dimensionRatioSide;
            this.horizontalWeight = source.horizontalWeight;
            this.verticalWeight = source.verticalWeight;
            this.horizontalChainStyle = source.horizontalChainStyle;
            this.verticalChainStyle = source.verticalChainStyle;
            this.constrainedWidth = source.constrainedWidth;
            this.constrainedHeight = source.constrainedHeight;
            this.matchConstraintDefaultWidth = source.matchConstraintDefaultWidth;
            this.matchConstraintDefaultHeight = source.matchConstraintDefaultHeight;
            this.matchConstraintMinWidth = source.matchConstraintMinWidth;
            this.matchConstraintMaxWidth = source.matchConstraintMaxWidth;
            this.matchConstraintMinHeight = source.matchConstraintMinHeight;
            this.matchConstraintMaxHeight = source.matchConstraintMaxHeight;
            this.matchConstraintPercentWidth = source.matchConstraintPercentWidth;
            this.matchConstraintPercentHeight = source.matchConstraintPercentHeight;
            this.editorAbsoluteX = source.editorAbsoluteX;
            this.editorAbsoluteY = source.editorAbsoluteY;
            this.orientation = source.orientation;
            this.horizontalDimensionFixed = source.horizontalDimensionFixed;
            this.verticalDimensionFixed = source.verticalDimensionFixed;
            this.needsBaseline = source.needsBaseline;
            this.isGuideline = source.isGuideline;
            this.resolvedLeftToLeft = source.resolvedLeftToLeft;
            this.resolvedLeftToRight = source.resolvedLeftToRight;
            this.resolvedRightToLeft = source.resolvedRightToLeft;
            this.resolvedRightToRight = source.resolvedRightToRight;
            this.resolveGoneLeftMargin = source.resolveGoneLeftMargin;
            this.resolveGoneRightMargin = source.resolveGoneRightMargin;
            this.resolvedHorizontalBias = source.resolvedHorizontalBias;
            this.widget = source.widget;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            ConstraintWidget constraintWidget;
            int commaIndex;
            Context c = context;
            AttributeSet attrs = attributeSet;
            super(c, attrs);
            ConstraintWidget constraintWidget2 = constraintWidget;
            ConstraintWidget constraintWidget3 = new ConstraintWidget();
            this.widget = constraintWidget2;
            this.helped = false;
            TypedArray a = c.obtainStyledAttributes(attrs, C0025R.styleable.ConstraintLayout_Layout);
            int N = a.getIndexCount();
            for (int i = 0; i < N; i++) {
                int attr = a.getIndex(i);
                switch (Table.map.get(attr)) {
                    case 1:
                        this.orientation = a.getInt(attr, this.orientation);
                        break;
                    case 2:
                        this.circleConstraint = a.getResourceId(attr, this.circleConstraint);
                        if (this.circleConstraint != -1) {
                            break;
                        } else {
                            this.circleConstraint = a.getInt(attr, -1);
                            break;
                        }
                    case 3:
                        this.circleRadius = a.getDimensionPixelSize(attr, this.circleRadius);
                        break;
                    case 4:
                        this.circleAngle = a.getFloat(attr, this.circleAngle) % 360.0f;
                        if (this.circleAngle >= 0.0f) {
                            break;
                        } else {
                            this.circleAngle = (360.0f - this.circleAngle) % 360.0f;
                            break;
                        }
                    case 5:
                        this.guideBegin = a.getDimensionPixelOffset(attr, this.guideBegin);
                        break;
                    case 6:
                        this.guideEnd = a.getDimensionPixelOffset(attr, this.guideEnd);
                        break;
                    case 7:
                        this.guidePercent = a.getFloat(attr, this.guidePercent);
                        break;
                    case 8:
                        this.leftToLeft = a.getResourceId(attr, this.leftToLeft);
                        if (this.leftToLeft != -1) {
                            break;
                        } else {
                            this.leftToLeft = a.getInt(attr, -1);
                            break;
                        }
                    case 9:
                        this.leftToRight = a.getResourceId(attr, this.leftToRight);
                        if (this.leftToRight != -1) {
                            break;
                        } else {
                            this.leftToRight = a.getInt(attr, -1);
                            break;
                        }
                    case 10:
                        this.rightToLeft = a.getResourceId(attr, this.rightToLeft);
                        if (this.rightToLeft != -1) {
                            break;
                        } else {
                            this.rightToLeft = a.getInt(attr, -1);
                            break;
                        }
                    case 11:
                        this.rightToRight = a.getResourceId(attr, this.rightToRight);
                        if (this.rightToRight != -1) {
                            break;
                        } else {
                            this.rightToRight = a.getInt(attr, -1);
                            break;
                        }
                    case 12:
                        this.topToTop = a.getResourceId(attr, this.topToTop);
                        if (this.topToTop != -1) {
                            break;
                        } else {
                            this.topToTop = a.getInt(attr, -1);
                            break;
                        }
                    case 13:
                        this.topToBottom = a.getResourceId(attr, this.topToBottom);
                        if (this.topToBottom != -1) {
                            break;
                        } else {
                            this.topToBottom = a.getInt(attr, -1);
                            break;
                        }
                    case 14:
                        this.bottomToTop = a.getResourceId(attr, this.bottomToTop);
                        if (this.bottomToTop != -1) {
                            break;
                        } else {
                            this.bottomToTop = a.getInt(attr, -1);
                            break;
                        }
                    case 15:
                        this.bottomToBottom = a.getResourceId(attr, this.bottomToBottom);
                        if (this.bottomToBottom != -1) {
                            break;
                        } else {
                            this.bottomToBottom = a.getInt(attr, -1);
                            break;
                        }
                    case 16:
                        this.baselineToBaseline = a.getResourceId(attr, this.baselineToBaseline);
                        if (this.baselineToBaseline != -1) {
                            break;
                        } else {
                            this.baselineToBaseline = a.getInt(attr, -1);
                            break;
                        }
                    case 17:
                        this.startToEnd = a.getResourceId(attr, this.startToEnd);
                        if (this.startToEnd != -1) {
                            break;
                        } else {
                            this.startToEnd = a.getInt(attr, -1);
                            break;
                        }
                    case 18:
                        this.startToStart = a.getResourceId(attr, this.startToStart);
                        if (this.startToStart != -1) {
                            break;
                        } else {
                            this.startToStart = a.getInt(attr, -1);
                            break;
                        }
                    case 19:
                        this.endToStart = a.getResourceId(attr, this.endToStart);
                        if (this.endToStart != -1) {
                            break;
                        } else {
                            this.endToStart = a.getInt(attr, -1);
                            break;
                        }
                    case 20:
                        this.endToEnd = a.getResourceId(attr, this.endToEnd);
                        if (this.endToEnd != -1) {
                            break;
                        } else {
                            this.endToEnd = a.getInt(attr, -1);
                            break;
                        }
                    case 21:
                        this.goneLeftMargin = a.getDimensionPixelSize(attr, this.goneLeftMargin);
                        break;
                    case 22:
                        this.goneTopMargin = a.getDimensionPixelSize(attr, this.goneTopMargin);
                        break;
                    case 23:
                        this.goneRightMargin = a.getDimensionPixelSize(attr, this.goneRightMargin);
                        break;
                    case 24:
                        this.goneBottomMargin = a.getDimensionPixelSize(attr, this.goneBottomMargin);
                        break;
                    case 25:
                        this.goneStartMargin = a.getDimensionPixelSize(attr, this.goneStartMargin);
                        break;
                    case 26:
                        this.goneEndMargin = a.getDimensionPixelSize(attr, this.goneEndMargin);
                        break;
                    case 27:
                        this.constrainedWidth = a.getBoolean(attr, this.constrainedWidth);
                        break;
                    case 28:
                        this.constrainedHeight = a.getBoolean(attr, this.constrainedHeight);
                        break;
                    case 29:
                        this.horizontalBias = a.getFloat(attr, this.horizontalBias);
                        break;
                    case 30:
                        this.verticalBias = a.getFloat(attr, this.verticalBias);
                        break;
                    case 31:
                        this.matchConstraintDefaultWidth = a.getInt(attr, 0);
                        if (this.matchConstraintDefaultWidth != 1) {
                            break;
                        } else {
                            int e = Log.e(ConstraintLayout.TAG, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                            break;
                        }
                    case 32:
                        this.matchConstraintDefaultHeight = a.getInt(attr, 0);
                        if (this.matchConstraintDefaultHeight != 1) {
                            break;
                        } else {
                            int e2 = Log.e(ConstraintLayout.TAG, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                            break;
                        }
                    case 33:
                        try {
                            this.matchConstraintMinWidth = a.getDimensionPixelSize(attr, this.matchConstraintMinWidth);
                            break;
                        } catch (Exception e3) {
                            Exception exc = e3;
                            if (a.getInt(attr, this.matchConstraintMinWidth) != -2) {
                                break;
                            } else {
                                this.matchConstraintMinWidth = -2;
                                break;
                            }
                        }
                    case 34:
                        try {
                            this.matchConstraintMaxWidth = a.getDimensionPixelSize(attr, this.matchConstraintMaxWidth);
                            break;
                        } catch (Exception e4) {
                            Exception exc2 = e4;
                            if (a.getInt(attr, this.matchConstraintMaxWidth) != -2) {
                                break;
                            } else {
                                this.matchConstraintMaxWidth = -2;
                                break;
                            }
                        }
                    case 35:
                        this.matchConstraintPercentWidth = Math.max(0.0f, a.getFloat(attr, this.matchConstraintPercentWidth));
                        break;
                    case 36:
                        try {
                            this.matchConstraintMinHeight = a.getDimensionPixelSize(attr, this.matchConstraintMinHeight);
                            break;
                        } catch (Exception e5) {
                            Exception exc3 = e5;
                            if (a.getInt(attr, this.matchConstraintMinHeight) != -2) {
                                break;
                            } else {
                                this.matchConstraintMinHeight = -2;
                                break;
                            }
                        }
                    case 37:
                        try {
                            this.matchConstraintMaxHeight = a.getDimensionPixelSize(attr, this.matchConstraintMaxHeight);
                            break;
                        } catch (Exception e6) {
                            Exception exc4 = e6;
                            if (a.getInt(attr, this.matchConstraintMaxHeight) != -2) {
                                break;
                            } else {
                                this.matchConstraintMaxHeight = -2;
                                break;
                            }
                        }
                    case 38:
                        this.matchConstraintPercentHeight = Math.max(0.0f, a.getFloat(attr, this.matchConstraintPercentHeight));
                        break;
                    case 44:
                        this.dimensionRatio = a.getString(attr);
                        this.dimensionRatioValue = Float.NaN;
                        this.dimensionRatioSide = -1;
                        if (this.dimensionRatio == null) {
                            break;
                        } else {
                            int len = this.dimensionRatio.length();
                            int commaIndex2 = this.dimensionRatio.indexOf(44);
                            if (commaIndex2 <= 0 || commaIndex2 >= len - 1) {
                                commaIndex = 0;
                            } else {
                                String dimension = this.dimensionRatio.substring(0, commaIndex2);
                                if (dimension.equalsIgnoreCase("W")) {
                                    this.dimensionRatioSide = 0;
                                } else if (dimension.equalsIgnoreCase("H")) {
                                    this.dimensionRatioSide = 1;
                                }
                                commaIndex = commaIndex2 + 1;
                            }
                            int colonIndex = this.dimensionRatio.indexOf(58);
                            if (colonIndex >= 0 && colonIndex < len - 1) {
                                String nominator = this.dimensionRatio.substring(commaIndex, colonIndex);
                                String denominator = this.dimensionRatio.substring(colonIndex + 1);
                                if (nominator.length() > 0 && denominator.length() > 0) {
                                    try {
                                        float nominatorValue = Float.parseFloat(nominator);
                                        float denominatorValue = Float.parseFloat(denominator);
                                        if (nominatorValue > 0.0f && denominatorValue > 0.0f) {
                                            if (this.dimensionRatioSide != 1) {
                                                this.dimensionRatioValue = Math.abs(nominatorValue / denominatorValue);
                                                break;
                                            } else {
                                                this.dimensionRatioValue = Math.abs(denominatorValue / nominatorValue);
                                                break;
                                            }
                                        }
                                    } catch (NumberFormatException e7) {
                                        NumberFormatException numberFormatException = e7;
                                        break;
                                    }
                                }
                            } else {
                                String r = this.dimensionRatio.substring(commaIndex);
                                if (r.length() <= 0) {
                                    break;
                                } else {
                                    try {
                                        this.dimensionRatioValue = Float.parseFloat(r);
                                        break;
                                    } catch (NumberFormatException e8) {
                                        NumberFormatException numberFormatException2 = e8;
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    case 45:
                        this.horizontalWeight = a.getFloat(attr, this.horizontalWeight);
                        break;
                    case 46:
                        this.verticalWeight = a.getFloat(attr, this.verticalWeight);
                        break;
                    case 47:
                        this.horizontalChainStyle = a.getInt(attr, 0);
                        break;
                    case 48:
                        this.verticalChainStyle = a.getInt(attr, 0);
                        break;
                    case 49:
                        this.editorAbsoluteX = a.getDimensionPixelOffset(attr, this.editorAbsoluteX);
                        break;
                    case 50:
                        this.editorAbsoluteY = a.getDimensionPixelOffset(attr, this.editorAbsoluteY);
                        break;
                }
            }
            a.recycle();
            validate();
        }

        public void validate() {
            Guideline guideline;
            this.isGuideline = false;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            if (this.width == -2 && this.constrainedWidth) {
                this.horizontalDimensionFixed = false;
                this.matchConstraintDefaultWidth = 1;
            }
            if (this.height == -2 && this.constrainedHeight) {
                this.verticalDimensionFixed = false;
                this.matchConstraintDefaultHeight = 1;
            }
            if (this.width == 0 || this.width == -1) {
                this.horizontalDimensionFixed = false;
                if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
                    this.width = -2;
                    this.constrainedWidth = true;
                }
            }
            if (this.height == 0 || this.height == -1) {
                this.verticalDimensionFixed = false;
                if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
                    this.height = -2;
                    this.constrainedHeight = true;
                }
            }
            if (this.guidePercent != -1.0f || this.guideBegin != -1 || this.guideEnd != -1) {
                this.isGuideline = true;
                this.horizontalDimensionFixed = true;
                this.verticalDimensionFixed = true;
                if (!(this.widget instanceof Guideline)) {
                    Guideline guideline2 = guideline;
                    Guideline guideline3 = new Guideline();
                    this.widget = guideline2;
                }
                ((Guideline) this.widget).setOrientation(this.orientation);
            }
        }

        public LayoutParams(int i, int i2) {
            ConstraintWidget constraintWidget;
            super(i, i2);
            ConstraintWidget constraintWidget2 = constraintWidget;
            ConstraintWidget constraintWidget3 = new ConstraintWidget();
            this.widget = constraintWidget2;
            this.helped = false;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            ConstraintWidget constraintWidget;
            super(layoutParams);
            ConstraintWidget constraintWidget2 = constraintWidget;
            ConstraintWidget constraintWidget3 = new ConstraintWidget();
            this.widget = constraintWidget2;
            this.helped = false;
        }

        @TargetApi(17)
        public void resolveLayoutDirection(int i) {
            int layoutDirection = i;
            int preLeftMargin = this.leftMargin;
            int preRightMargin = this.rightMargin;
            super.resolveLayoutDirection(layoutDirection);
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolveGoneLeftMargin = this.goneLeftMargin;
            this.resolveGoneRightMargin = this.goneRightMargin;
            this.resolvedHorizontalBias = this.horizontalBias;
            this.resolvedGuideBegin = this.guideBegin;
            this.resolvedGuideEnd = this.guideEnd;
            this.resolvedGuidePercent = this.guidePercent;
            if (1 == getLayoutDirection()) {
                boolean startEndDefined = false;
                if (this.startToEnd != -1) {
                    this.resolvedRightToLeft = this.startToEnd;
                    startEndDefined = true;
                } else if (this.startToStart != -1) {
                    this.resolvedRightToRight = this.startToStart;
                    startEndDefined = true;
                }
                if (this.endToStart != -1) {
                    this.resolvedLeftToRight = this.endToStart;
                    startEndDefined = true;
                }
                if (this.endToEnd != -1) {
                    this.resolvedLeftToLeft = this.endToEnd;
                    startEndDefined = true;
                }
                if (this.goneStartMargin != -1) {
                    this.resolveGoneRightMargin = this.goneStartMargin;
                }
                if (this.goneEndMargin != -1) {
                    this.resolveGoneLeftMargin = this.goneEndMargin;
                }
                if (startEndDefined) {
                    this.resolvedHorizontalBias = 1.0f - this.horizontalBias;
                }
                if (this.isGuideline && this.orientation == 1) {
                    if (this.guidePercent != -1.0f) {
                        this.resolvedGuidePercent = 1.0f - this.guidePercent;
                        this.resolvedGuideBegin = -1;
                        this.resolvedGuideEnd = -1;
                    } else if (this.guideBegin != -1) {
                        this.resolvedGuideEnd = this.guideBegin;
                        this.resolvedGuideBegin = -1;
                        this.resolvedGuidePercent = -1.0f;
                    } else if (this.guideEnd != -1) {
                        this.resolvedGuideBegin = this.guideEnd;
                        this.resolvedGuideEnd = -1;
                        this.resolvedGuidePercent = -1.0f;
                    }
                }
            } else {
                if (this.startToEnd != -1) {
                    this.resolvedLeftToRight = this.startToEnd;
                }
                if (this.startToStart != -1) {
                    this.resolvedLeftToLeft = this.startToStart;
                }
                if (this.endToStart != -1) {
                    this.resolvedRightToLeft = this.endToStart;
                }
                if (this.endToEnd != -1) {
                    this.resolvedRightToRight = this.endToEnd;
                }
                if (this.goneStartMargin != -1) {
                    this.resolveGoneLeftMargin = this.goneStartMargin;
                }
                if (this.goneEndMargin != -1) {
                    this.resolveGoneRightMargin = this.goneEndMargin;
                }
            }
            if (this.endToStart == -1 && this.endToEnd == -1 && this.startToStart == -1 && this.startToEnd == -1) {
                if (this.rightToLeft != -1) {
                    this.resolvedRightToLeft = this.rightToLeft;
                    if (this.rightMargin <= 0 && preRightMargin > 0) {
                        this.rightMargin = preRightMargin;
                    }
                } else if (this.rightToRight != -1) {
                    this.resolvedRightToRight = this.rightToRight;
                    if (this.rightMargin <= 0 && preRightMargin > 0) {
                        this.rightMargin = preRightMargin;
                    }
                }
                if (this.leftToLeft != -1) {
                    this.resolvedLeftToLeft = this.leftToLeft;
                    if (this.leftMargin <= 0 && preLeftMargin > 0) {
                        this.leftMargin = preLeftMargin;
                    }
                } else if (this.leftToRight != -1) {
                    this.resolvedLeftToRight = this.leftToRight;
                    if (this.leftMargin <= 0 && preLeftMargin > 0) {
                        this.leftMargin = preLeftMargin;
                    }
                }
            }
        }
    }

    public void setDesignInformation(int i, Object obj, Object obj2) {
        HashMap<String, Integer> hashMap;
        Object value1 = obj;
        Object value2 = obj2;
        if (i == 0 && (value1 instanceof String) && (value2 instanceof Integer)) {
            if (this.mDesignIds == null) {
                HashMap<String, Integer> hashMap2 = hashMap;
                HashMap<String, Integer> hashMap3 = new HashMap<>();
                this.mDesignIds = hashMap2;
            }
            String name = (String) value1;
            int index = name.indexOf("/");
            if (index != -1) {
                name = name.substring(index + 1);
            }
            Object put = this.mDesignIds.put(name, Integer.valueOf(((Integer) value2).intValue()));
        }
    }

    public Object getDesignInformation(int i, Object obj) {
        Object value = obj;
        if (i == 0 && (value instanceof String)) {
            String name = (String) value;
            if (this.mDesignIds != null && this.mDesignIds.containsKey(name)) {
                return this.mDesignIds.get(name);
            }
        }
        return null;
    }

    public ConstraintLayout(Context context) {
        SparseArray<View> sparseArray;
        ArrayList<ConstraintHelper> arrayList;
        ArrayList<ConstraintWidget> arrayList2;
        ConstraintWidgetContainer constraintWidgetContainer;
        HashMap<String, Integer> hashMap;
        super(context);
        SparseArray<View> sparseArray2 = sparseArray;
        SparseArray<View> sparseArray3 = new SparseArray<>();
        this.mChildrenByIds = sparseArray2;
        ArrayList<ConstraintHelper> arrayList3 = arrayList;
        ArrayList<ConstraintHelper> arrayList4 = new ArrayList<>(4);
        this.mConstraintHelpers = arrayList3;
        ArrayList<ConstraintWidget> arrayList5 = arrayList2;
        ArrayList<ConstraintWidget> arrayList6 = new ArrayList<>(100);
        this.mVariableDimensionsWidgets = arrayList5;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        ConstraintWidgetContainer constraintWidgetContainer3 = new ConstraintWidgetContainer();
        this.mLayoutWidget = constraintWidgetContainer2;
        HashMap<String, Integer> hashMap2 = hashMap;
        HashMap<String, Integer> hashMap3 = new HashMap<>();
        this.mDesignIds = hashMap2;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        init(null);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        SparseArray<View> sparseArray;
        ArrayList<ConstraintHelper> arrayList;
        ArrayList<ConstraintWidget> arrayList2;
        ConstraintWidgetContainer constraintWidgetContainer;
        HashMap<String, Integer> hashMap;
        AttributeSet attrs = attributeSet;
        super(context, attrs);
        SparseArray<View> sparseArray2 = sparseArray;
        SparseArray<View> sparseArray3 = new SparseArray<>();
        this.mChildrenByIds = sparseArray2;
        ArrayList<ConstraintHelper> arrayList3 = arrayList;
        ArrayList<ConstraintHelper> arrayList4 = new ArrayList<>(4);
        this.mConstraintHelpers = arrayList3;
        ArrayList<ConstraintWidget> arrayList5 = arrayList2;
        ArrayList<ConstraintWidget> arrayList6 = new ArrayList<>(100);
        this.mVariableDimensionsWidgets = arrayList5;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        ConstraintWidgetContainer constraintWidgetContainer3 = new ConstraintWidgetContainer();
        this.mLayoutWidget = constraintWidgetContainer2;
        HashMap<String, Integer> hashMap2 = hashMap;
        HashMap<String, Integer> hashMap3 = new HashMap<>();
        this.mDesignIds = hashMap2;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        init(attrs);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        SparseArray<View> sparseArray;
        ArrayList<ConstraintHelper> arrayList;
        ArrayList<ConstraintWidget> arrayList2;
        ConstraintWidgetContainer constraintWidgetContainer;
        HashMap<String, Integer> hashMap;
        AttributeSet attrs = attributeSet;
        super(context, attrs, i);
        SparseArray<View> sparseArray2 = sparseArray;
        SparseArray<View> sparseArray3 = new SparseArray<>();
        this.mChildrenByIds = sparseArray2;
        ArrayList<ConstraintHelper> arrayList3 = arrayList;
        ArrayList<ConstraintHelper> arrayList4 = new ArrayList<>(4);
        this.mConstraintHelpers = arrayList3;
        ArrayList<ConstraintWidget> arrayList5 = arrayList2;
        ArrayList<ConstraintWidget> arrayList6 = new ArrayList<>(100);
        this.mVariableDimensionsWidgets = arrayList5;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        ConstraintWidgetContainer constraintWidgetContainer3 = new ConstraintWidgetContainer();
        this.mLayoutWidget = constraintWidgetContainer2;
        HashMap<String, Integer> hashMap2 = hashMap;
        HashMap<String, Integer> hashMap3 = new HashMap<>();
        this.mDesignIds = hashMap2;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        init(attrs);
    }

    public void setId(int i) {
        int id = i;
        this.mChildrenByIds.remove(getId());
        super.setId(id);
        this.mChildrenByIds.put(getId(), this);
    }

    private void init(AttributeSet attributeSet) {
        ConstraintSet constraintSet;
        AttributeSet attrs = attributeSet;
        this.mLayoutWidget.setCompanionWidget(this);
        this.mChildrenByIds.put(getId(), this);
        this.mConstraintSet = null;
        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs, C0025R.styleable.ConstraintLayout_Layout);
            int N = a.getIndexCount();
            for (int i = 0; i < N; i++) {
                int attr = a.getIndex(i);
                if (attr == C0025R.styleable.ConstraintLayout_Layout_android_minWidth) {
                    this.mMinWidth = a.getDimensionPixelOffset(attr, this.mMinWidth);
                } else if (attr == C0025R.styleable.ConstraintLayout_Layout_android_minHeight) {
                    this.mMinHeight = a.getDimensionPixelOffset(attr, this.mMinHeight);
                } else if (attr == C0025R.styleable.ConstraintLayout_Layout_android_maxWidth) {
                    this.mMaxWidth = a.getDimensionPixelOffset(attr, this.mMaxWidth);
                } else if (attr == C0025R.styleable.ConstraintLayout_Layout_android_maxHeight) {
                    this.mMaxHeight = a.getDimensionPixelOffset(attr, this.mMaxHeight);
                } else if (attr == C0025R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
                    this.mOptimizationLevel = a.getInt(attr, this.mOptimizationLevel);
                } else if (attr == C0025R.styleable.ConstraintLayout_Layout_constraintSet) {
                    int id = a.getResourceId(attr, 0);
                    try {
                        ConstraintSet constraintSet2 = constraintSet;
                        ConstraintSet constraintSet3 = new ConstraintSet();
                        this.mConstraintSet = constraintSet2;
                        this.mConstraintSet.load(getContext(), id);
                    } catch (NotFoundException e) {
                        NotFoundException notFoundException = e;
                        this.mConstraintSet = null;
                    }
                    this.mConstraintSetId = id;
                }
            }
            a.recycle();
        }
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
    }

    public void addView(View view, int i, android.view.ViewGroup.LayoutParams layoutParams) {
        View child = view;
        super.addView(child, i, layoutParams);
        if (VERSION.SDK_INT < 14) {
            onViewAdded(child);
        }
    }

    public void removeView(View view) {
        View view2 = view;
        super.removeView(view2);
        if (VERSION.SDK_INT < 14) {
            onViewRemoved(view2);
        }
    }

    public void onViewAdded(View view) {
        Guideline guideline;
        View view2 = view;
        if (VERSION.SDK_INT >= 14) {
            super.onViewAdded(view2);
        }
        ConstraintWidget widget = getViewWidget(view2);
        if ((view2 instanceof Guideline) && !(widget instanceof Guideline)) {
            LayoutParams layoutParams = (LayoutParams) view2.getLayoutParams();
            LayoutParams layoutParams2 = layoutParams;
            Guideline guideline2 = guideline;
            Guideline guideline3 = new Guideline();
            layoutParams2.widget = guideline2;
            layoutParams.isGuideline = true;
            ((Guideline) layoutParams.widget).setOrientation(layoutParams.orientation);
        }
        if (view2 instanceof ConstraintHelper) {
            ConstraintHelper helper = (ConstraintHelper) view2;
            helper.validateParams();
            ((LayoutParams) view2.getLayoutParams()).isHelper = true;
            if (!this.mConstraintHelpers.contains(helper)) {
                boolean add = this.mConstraintHelpers.add(helper);
            }
        }
        this.mChildrenByIds.put(view2.getId(), view2);
        this.mDirtyHierarchy = true;
    }

    public void onViewRemoved(View view) {
        View view2 = view;
        if (VERSION.SDK_INT >= 14) {
            super.onViewRemoved(view2);
        }
        this.mChildrenByIds.remove(view2.getId());
        ConstraintWidget widget = getViewWidget(view2);
        this.mLayoutWidget.remove(widget);
        boolean remove = this.mConstraintHelpers.remove(view2);
        boolean remove2 = this.mVariableDimensionsWidgets.remove(widget);
        this.mDirtyHierarchy = true;
    }

    public void setMinWidth(int i) {
        int value = i;
        if (value != this.mMinWidth) {
            this.mMinWidth = value;
            requestLayout();
        }
    }

    public void setMinHeight(int i) {
        int value = i;
        if (value != this.mMinHeight) {
            this.mMinHeight = value;
            requestLayout();
        }
    }

    public int getMinWidth() {
        return this.mMinWidth;
    }

    public int getMinHeight() {
        return this.mMinHeight;
    }

    public void setMaxWidth(int i) {
        int value = i;
        if (value != this.mMaxWidth) {
            this.mMaxWidth = value;
            requestLayout();
        }
    }

    public void setMaxHeight(int i) {
        int value = i;
        if (value != this.mMaxHeight) {
            this.mMaxHeight = value;
            requestLayout();
        }
    }

    public int getMaxWidth() {
        return this.mMaxWidth;
    }

    public int getMaxHeight() {
        return this.mMaxHeight;
    }

    private void updateHierarchy() {
        int count = getChildCount();
        boolean recompute = false;
        int i = 0;
        while (true) {
            if (i >= count) {
                break;
            } else if (getChildAt(i).isLayoutRequested()) {
                recompute = true;
                break;
            } else {
                i++;
            }
        }
        if (recompute) {
            this.mVariableDimensionsWidgets.clear();
            setChildrenConstraints();
        }
    }

    /* JADX WARNING: type inference failed for: r22v28, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r9v0 */
    /* JADX WARNING: type inference failed for: r22v29, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v30 */
    /* JADX WARNING: type inference failed for: r0v12, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v43 */
    /* JADX WARNING: type inference failed for: r0v14, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v48 */
    /* JADX WARNING: type inference failed for: r0v18, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v50 */
    /* JADX WARNING: type inference failed for: r0v20, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v52 */
    /* JADX WARNING: type inference failed for: r0v22, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v54 */
    /* JADX WARNING: type inference failed for: r0v25, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v56 */
    /* JADX WARNING: type inference failed for: r0v27, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v58 */
    /* JADX WARNING: type inference failed for: r0v29, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v60 */
    /* JADX WARNING: type inference failed for: r0v31, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v62 */
    /* JADX WARNING: type inference failed for: r0v33, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v64 */
    /* JADX WARNING: type inference failed for: r0v35, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v66 */
    /* JADX WARNING: type inference failed for: r0v37, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v69 */
    /* JADX WARNING: type inference failed for: r0v40, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v0 */
    /* JADX WARNING: type inference failed for: r0v45, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v2 */
    /* JADX WARNING: type inference failed for: r0v49, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v83 */
    /* JADX WARNING: type inference failed for: r0v51, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v85 */
    /* JADX WARNING: type inference failed for: r0v54, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v32 */
    /* JADX WARNING: type inference failed for: r0v57, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v4 */
    /* JADX WARNING: type inference failed for: r0v59, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r27v2 */
    /* JADX WARNING: type inference failed for: r0v61, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v91 */
    /* JADX WARNING: type inference failed for: r0v63, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v93 */
    /* JADX WARNING: type inference failed for: r0v66, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v37 */
    /* JADX WARNING: type inference failed for: r0v69, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v6 */
    /* JADX WARNING: type inference failed for: r0v71, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r27v4 */
    /* JADX WARNING: type inference failed for: r0v73, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v99 */
    /* JADX WARNING: type inference failed for: r0v75, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v103 */
    /* JADX WARNING: type inference failed for: r0v78, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v106 */
    /* JADX WARNING: type inference failed for: r0v80, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v44 */
    /* JADX WARNING: type inference failed for: r0v82, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v48 */
    /* JADX WARNING: type inference failed for: r0v86, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v50 */
    /* JADX WARNING: type inference failed for: r0v88, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v127 */
    /* JADX WARNING: type inference failed for: r1v16, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v59 */
    /* JADX WARNING: type inference failed for: r0v94, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v9 */
    /* JADX WARNING: type inference failed for: r0v96, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r27v7 */
    /* JADX WARNING: type inference failed for: r0v98, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v62 */
    /* JADX WARNING: type inference failed for: r0v100, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v11 */
    /* JADX WARNING: type inference failed for: r0v102, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r27v9 */
    /* JADX WARNING: type inference failed for: r0v104, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v13 */
    /* JADX WARNING: type inference failed for: r0v106, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v15 */
    /* JADX WARNING: type inference failed for: r0v108, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v156 */
    /* JADX WARNING: type inference failed for: r0v110, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v70 */
    /* JADX WARNING: type inference failed for: r0v112, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v160 */
    /* JADX WARNING: type inference failed for: r0v114, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v73 */
    /* JADX WARNING: type inference failed for: r0v116, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v164 */
    /* JADX WARNING: type inference failed for: r0v118, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v75 */
    /* JADX WARNING: type inference failed for: r0v120, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v77 */
    /* JADX WARNING: type inference failed for: r0v122, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v79 */
    /* JADX WARNING: type inference failed for: r0v124, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v81 */
    /* JADX WARNING: type inference failed for: r0v126, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v83 */
    /* JADX WARNING: type inference failed for: r0v128, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r24v12 */
    /* JADX WARNING: type inference failed for: r0v130, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r25v12 */
    /* JADX WARNING: type inference failed for: r0v132, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v17 */
    /* JADX WARNING: type inference failed for: r0v134, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v85 */
    /* JADX WARNING: type inference failed for: r0v136, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r24v14 */
    /* JADX WARNING: type inference failed for: r0v138, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r25v14 */
    /* JADX WARNING: type inference failed for: r0v140, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r26v19 */
    /* JADX WARNING: type inference failed for: r0v142, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v87 */
    /* JADX WARNING: type inference failed for: r0v144, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v173 */
    /* JADX WARNING: type inference failed for: r0v146, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v94 */
    /* JADX WARNING: type inference failed for: r0v149, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v97 */
    /* JADX WARNING: type inference failed for: r0v152, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v182 */
    /* JADX WARNING: type inference failed for: r0v155, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v104 */
    /* JADX WARNING: type inference failed for: r0v158, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v107 */
    /* JADX WARNING: type inference failed for: r0v161, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v191 */
    /* JADX WARNING: type inference failed for: r0v164, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v110 */
    /* JADX WARNING: type inference failed for: r0v167, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r24v16 */
    /* JADX WARNING: type inference failed for: r0v169, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v194 */
    /* JADX WARNING: type inference failed for: r0v171, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r23v113 */
    /* JADX WARNING: type inference failed for: r0v174, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r24v18 */
    /* JADX WARNING: type inference failed for: r0v176, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r25v16 */
    /* JADX WARNING: type inference failed for: r0v178, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v200 */
    /* JADX WARNING: type inference failed for: r0v180, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v202 */
    /* JADX WARNING: type inference failed for: r0v182, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v204 */
    /* JADX WARNING: type inference failed for: r0v184, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v206 */
    /* JADX WARNING: type inference failed for: r0v186, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v208 */
    /* JADX WARNING: type inference failed for: r0v188, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v210 */
    /* JADX WARNING: type inference failed for: r0v190, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v212 */
    /* JADX WARNING: type inference failed for: r0v192, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v217 */
    /* JADX WARNING: type inference failed for: r0v197, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v219 */
    /* JADX WARNING: type inference failed for: r0v200, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v221 */
    /* JADX WARNING: type inference failed for: r0v203, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v223 */
    /* JADX WARNING: type inference failed for: r0v205, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v226 */
    /* JADX WARNING: type inference failed for: r0v208, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v228 */
    /* JADX WARNING: type inference failed for: r0v211, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v230 */
    /* JADX WARNING: type inference failed for: r0v214, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v232 */
    /* JADX WARNING: type inference failed for: r0v216, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v234 */
    /* JADX WARNING: type inference failed for: r0v218, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v236 */
    /* JADX WARNING: type inference failed for: r0v221, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v238 */
    /* JADX WARNING: type inference failed for: r0v224, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v240 */
    /* JADX WARNING: type inference failed for: r0v227, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v242 */
    /* JADX WARNING: type inference failed for: r0v230, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v244 */
    /* JADX WARNING: type inference failed for: r0v233, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v246 */
    /* JADX WARNING: type inference failed for: r0v236, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v248 */
    /* JADX WARNING: type inference failed for: r0v239, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v250 */
    /* JADX WARNING: type inference failed for: r0v242, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v252 */
    /* JADX WARNING: type inference failed for: r0v245, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v254 */
    /* JADX WARNING: type inference failed for: r0v248, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v256 */
    /* JADX WARNING: type inference failed for: r0v251, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v258 */
    /* JADX WARNING: type inference failed for: r0v254, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v260 */
    /* JADX WARNING: type inference failed for: r0v257, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v262 */
    /* JADX WARNING: type inference failed for: r0v260, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v264 */
    /* JADX WARNING: type inference failed for: r0v263, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v266 */
    /* JADX WARNING: type inference failed for: r0v266, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v270 */
    /* JADX WARNING: type inference failed for: r0v269, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v272 */
    /* JADX WARNING: type inference failed for: r0v271, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v274 */
    /* JADX WARNING: type inference failed for: r0v273, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v284 */
    /* JADX WARNING: type inference failed for: r0v278, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v286 */
    /* JADX WARNING: type inference failed for: r0v280, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v288 */
    /* JADX WARNING: type inference failed for: r0v282, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v293 */
    /* JADX WARNING: type inference failed for: r0v286, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r22v296 */
    /* JADX WARNING: type inference failed for: r1v54, types: [android.support.constraint.ConstraintLayout$LayoutParams] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 225 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void setChildrenConstraints() {
        /*
            r29 = this;
            r2 = r29
            r22 = r2
            boolean r22 = r22.isInEditMode()
            r3 = r22
            r22 = r2
            int r22 = r22.getChildCount()
            r4 = r22
            r22 = r3
            if (r22 == 0) goto L_0x008d
            r22 = 0
            r5 = r22
        L_0x001a:
            r22 = r5
            r23 = r4
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x008d
            r22 = r2
            r23 = r5
            android.view.View r22 = r22.getChildAt(r23)
            r6 = r22
            r22 = r2
            android.content.res.Resources r22 = r22.getResources()     // Catch:{ NotFoundException -> 0x0089 }
            r23 = r6
            int r23 = r23.getId()     // Catch:{ NotFoundException -> 0x0089 }
            java.lang.String r22 = r22.getResourceName(r23)     // Catch:{ NotFoundException -> 0x0089 }
            r7 = r22
            r22 = r2
            r23 = 0
            r24 = r7
            r25 = r6
            int r25 = r25.getId()     // Catch:{ NotFoundException -> 0x0089 }
            java.lang.Integer r25 = java.lang.Integer.valueOf(r25)     // Catch:{ NotFoundException -> 0x0089 }
            r22.setDesignInformation(r23, r24, r25)     // Catch:{ NotFoundException -> 0x0089 }
            r22 = r7
            r23 = 47
            int r22 = r22.indexOf(r23)     // Catch:{ NotFoundException -> 0x0089 }
            r8 = r22
            r22 = r8
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0075
            r22 = r7
            r23 = r8
            r24 = 1
            int r23 = r23 + 1
            java.lang.String r22 = r22.substring(r23)     // Catch:{ NotFoundException -> 0x0089 }
            r7 = r22
        L_0x0075:
            r22 = r2
            r23 = r6
            int r23 = r23.getId()     // Catch:{ NotFoundException -> 0x0089 }
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)     // Catch:{ NotFoundException -> 0x0089 }
            r23 = r7
            r22.setDebugName(r23)     // Catch:{ NotFoundException -> 0x0089 }
        L_0x0086:
            int r5 = r5 + 1
            goto L_0x001a
        L_0x0089:
            r22 = move-exception
            r7 = r22
            goto L_0x0086
        L_0x008d:
            r22 = 0
            r5 = r22
        L_0x0091:
            r22 = r5
            r23 = r4
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x00bc
            r22 = r2
            r23 = r5
            android.view.View r22 = r22.getChildAt(r23)
            r6 = r22
            r22 = r2
            r23 = r6
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getViewWidget(r23)
            r7 = r22
            r22 = r7
            if (r22 != 0) goto L_0x00b6
        L_0x00b3:
            int r5 = r5 + 1
            goto L_0x0091
        L_0x00b6:
            r22 = r7
            r22.reset()
            goto L_0x00b3
        L_0x00bc:
            r22 = r2
            r0 = r22
            int r0 = r0.mConstraintSetId
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0115
            r22 = 0
            r5 = r22
        L_0x00d0:
            r22 = r5
            r23 = r4
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x0115
            r22 = r2
            r23 = r5
            android.view.View r22 = r22.getChildAt(r23)
            r6 = r22
            r22 = r6
            int r22 = r22.getId()
            r23 = r2
            r0 = r23
            int r0 = r0.mConstraintSetId
            r23 = r0
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0112
            r22 = r6
            r0 = r22
            boolean r0 = r0 instanceof android.support.constraint.Constraints
            r22 = r0
            if (r22 == 0) goto L_0x0112
            r22 = r2
            r23 = r6
            android.support.constraint.Constraints r23 = (android.support.constraint.Constraints) r23
            android.support.constraint.ConstraintSet r23 = r23.getConstraintSet()
            r0 = r23
            r1 = r22
            r1.mConstraintSet = r0
        L_0x0112:
            int r5 = r5 + 1
            goto L_0x00d0
        L_0x0115:
            r22 = r2
            r0 = r22
            android.support.constraint.ConstraintSet r0 = r0.mConstraintSet
            r22 = r0
            if (r22 == 0) goto L_0x012c
            r22 = r2
            r0 = r22
            android.support.constraint.ConstraintSet r0 = r0.mConstraintSet
            r22 = r0
            r23 = r2
            r22.applyToInternal(r23)
        L_0x012c:
            r22 = r2
            r0 = r22
            android.support.constraint.solver.widgets.ConstraintWidgetContainer r0 = r0.mLayoutWidget
            r22 = r0
            r22.removeAllChildren()
            r22 = r2
            r0 = r22
            java.util.ArrayList<android.support.constraint.ConstraintHelper> r0 = r0.mConstraintHelpers
            r22 = r0
            int r22 = r22.size()
            r5 = r22
            r22 = r5
            if (r22 <= 0) goto L_0x0173
            r22 = 0
            r6 = r22
        L_0x014d:
            r22 = r6
            r23 = r5
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x0173
            r22 = r2
            r0 = r22
            java.util.ArrayList<android.support.constraint.ConstraintHelper> r0 = r0.mConstraintHelpers
            r22 = r0
            r23 = r6
            java.lang.Object r22 = r22.get(r23)
            android.support.constraint.ConstraintHelper r22 = (android.support.constraint.ConstraintHelper) r22
            r7 = r22
            r22 = r7
            r23 = r2
            r22.updatePreLayout(r23)
            int r6 = r6 + 1
            goto L_0x014d
        L_0x0173:
            r22 = 0
            r6 = r22
        L_0x0177:
            r22 = r6
            r23 = r4
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x01a1
            r22 = r2
            r23 = r6
            android.view.View r22 = r22.getChildAt(r23)
            r7 = r22
            r22 = r7
            r0 = r22
            boolean r0 = r0 instanceof android.support.constraint.Placeholder
            r22 = r0
            if (r22 == 0) goto L_0x019e
            r22 = r7
            android.support.constraint.Placeholder r22 = (android.support.constraint.Placeholder) r22
            r23 = r2
            r22.updatePreLayout(r23)
        L_0x019e:
            int r6 = r6 + 1
            goto L_0x0177
        L_0x01a1:
            r22 = 0
            r6 = r22
        L_0x01a5:
            r22 = r6
            r23 = r4
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x09fd
            r22 = r2
            r23 = r6
            android.view.View r22 = r22.getChildAt(r23)
            r7 = r22
            r22 = r2
            r23 = r7
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getViewWidget(r23)
            r8 = r22
            r22 = r8
            if (r22 != 0) goto L_0x01ca
        L_0x01c7:
            int r6 = r6 + 1
            goto L_0x01a5
        L_0x01ca:
            r22 = r7
            android.view.ViewGroup$LayoutParams r22 = r22.getLayoutParams()
            android.support.constraint.ConstraintLayout$LayoutParams r22 = (android.support.constraint.ConstraintLayout.LayoutParams) r22
            r9 = r22
            r22 = r9
            r22.validate()
            r22 = r9
            r0 = r22
            boolean r0 = r0.helped
            r22 = r0
            if (r22 == 0) goto L_0x02a6
            r22 = r9
            r23 = 0
            r0 = r23
            r1 = r22
            r1.helped = r0
        L_0x01ed:
            r22 = r8
            r23 = r7
            int r23 = r23.getVisibility()
            r22.setVisibility(r23)
            r22 = r9
            r0 = r22
            boolean r0 = r0.isInPlaceholder
            r22 = r0
            if (r22 == 0) goto L_0x0209
            r22 = r8
            r23 = 8
            r22.setVisibility(r23)
        L_0x0209:
            r22 = r8
            r23 = r7
            r22.setCompanionWidget(r23)
            r22 = r2
            r0 = r22
            android.support.constraint.solver.widgets.ConstraintWidgetContainer r0 = r0.mLayoutWidget
            r22 = r0
            r23 = r8
            r22.add(r23)
            r22 = r9
            r0 = r22
            boolean r0 = r0.verticalDimensionFixed
            r22 = r0
            if (r22 == 0) goto L_0x0231
            r22 = r9
            r0 = r22
            boolean r0 = r0.horizontalDimensionFixed
            r22 = r0
            if (r22 != 0) goto L_0x023f
        L_0x0231:
            r22 = r2
            r0 = r22
            java.util.ArrayList<android.support.constraint.solver.widgets.ConstraintWidget> r0 = r0.mVariableDimensionsWidgets
            r22 = r0
            r23 = r8
            boolean r22 = r22.add(r23)
        L_0x023f:
            r22 = r9
            r0 = r22
            boolean r0 = r0.isGuideline
            r22 = r0
            if (r22 == 0) goto L_0x0320
            r22 = r8
            android.support.constraint.solver.widgets.Guideline r22 = (android.support.constraint.solver.widgets.Guideline) r22
            r10 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedGuideBegin
            r22 = r0
            r11 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedGuideEnd
            r22 = r0
            r12 = r22
            r22 = r9
            r0 = r22
            float r0 = r0.resolvedGuidePercent
            r22 = r0
            r13 = r22
            int r22 = android.os.Build.VERSION.SDK_INT
            r23 = 17
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x0295
            r22 = r9
            r0 = r22
            int r0 = r0.guideBegin
            r22 = r0
            r11 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.guideEnd
            r22 = r0
            r12 = r22
            r22 = r9
            r0 = r22
            float r0 = r0.guidePercent
            r22 = r0
            r13 = r22
        L_0x0295:
            r22 = r13
            r23 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1))
            if (r22 == 0) goto L_0x02fc
            r22 = r10
            r23 = r13
            r22.setGuidePercent(r23)
        L_0x02a4:
            goto L_0x01c7
        L_0x02a6:
            r22 = r3
            if (r22 == 0) goto L_0x01ed
            r22 = r2
            android.content.res.Resources r22 = r22.getResources()     // Catch:{ NotFoundException -> 0x02f7 }
            r23 = r7
            int r23 = r23.getId()     // Catch:{ NotFoundException -> 0x02f7 }
            java.lang.String r22 = r22.getResourceName(r23)     // Catch:{ NotFoundException -> 0x02f7 }
            r10 = r22
            r22 = r2
            r23 = 0
            r24 = r10
            r25 = r7
            int r25 = r25.getId()     // Catch:{ NotFoundException -> 0x02f7 }
            java.lang.Integer r25 = java.lang.Integer.valueOf(r25)     // Catch:{ NotFoundException -> 0x02f7 }
            r22.setDesignInformation(r23, r24, r25)     // Catch:{ NotFoundException -> 0x02f7 }
            r22 = r10
            r23 = r10
            java.lang.String r24 = "id/"
            int r23 = r23.indexOf(r24)     // Catch:{ NotFoundException -> 0x02f7 }
            r24 = 3
            int r23 = r23 + 3
            java.lang.String r22 = r22.substring(r23)     // Catch:{ NotFoundException -> 0x02f7 }
            r10 = r22
            r22 = r2
            r23 = r7
            int r23 = r23.getId()     // Catch:{ NotFoundException -> 0x02f7 }
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)     // Catch:{ NotFoundException -> 0x02f7 }
            r23 = r10
            r22.setDebugName(r23)     // Catch:{ NotFoundException -> 0x02f7 }
            goto L_0x01ed
        L_0x02f7:
            r22 = move-exception
            r10 = r22
            goto L_0x01ed
        L_0x02fc:
            r22 = r11
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x030e
            r22 = r10
            r23 = r11
            r22.setGuideBegin(r23)
            goto L_0x02a4
        L_0x030e:
            r22 = r12
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x02a4
            r22 = r10
            r23 = r12
            r22.setGuideEnd(r23)
            goto L_0x02a4
        L_0x0320:
            r22 = r9
            r0 = r22
            int r0 = r0.leftToLeft
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.leftToRight
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.rightToLeft
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.rightToRight
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.startToStart
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.startToEnd
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.endToStart
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.endToEnd
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.topToTop
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.topToBottom
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.bottomToTop
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.bottomToBottom
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.baselineToBaseline
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.editorAbsoluteX
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.editorAbsoluteY
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.circleConstraint
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.width
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0440
            r22 = r9
            r0 = r22
            int r0 = r0.height
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x01c7
        L_0x0440:
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedLeftToLeft
            r22 = r0
            r10 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedLeftToRight
            r22 = r0
            r11 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedRightToLeft
            r22 = r0
            r12 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolvedRightToRight
            r22 = r0
            r13 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolveGoneLeftMargin
            r22 = r0
            r14 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.resolveGoneRightMargin
            r22 = r0
            r15 = r22
            r22 = r9
            r0 = r22
            float r0 = r0.resolvedHorizontalBias
            r22 = r0
            r16 = r22
            int r22 = android.os.Build.VERSION.SDK_INT
            r23 = 17
            r0 = r22
            r1 = r23
            if (r0 >= r1) goto L_0x0532
            r22 = r9
            r0 = r22
            int r0 = r0.leftToLeft
            r22 = r0
            r10 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.leftToRight
            r22 = r0
            r11 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.rightToLeft
            r22 = r0
            r12 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.rightToRight
            r22 = r0
            r13 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.goneLeftMargin
            r22 = r0
            r14 = r22
            r22 = r9
            r0 = r22
            int r0 = r0.goneRightMargin
            r22 = r0
            r15 = r22
            r22 = r9
            r0 = r22
            float r0 = r0.horizontalBias
            r22 = r0
            r16 = r22
            r22 = r10
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0504
            r22 = r11
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0504
            r22 = r9
            r0 = r22
            int r0 = r0.startToStart
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x06d7
            r22 = r9
            r0 = r22
            int r0 = r0.startToStart
            r22 = r0
            r10 = r22
        L_0x0504:
            r22 = r12
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0532
            r22 = r13
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0532
            r22 = r9
            r0 = r22
            int r0 = r0.endToStart
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x06f3
            r22 = r9
            r0 = r22
            int r0 = r0.endToStart
            r22 = r0
            r12 = r22
        L_0x0532:
            r22 = r9
            r0 = r22
            int r0 = r0.circleConstraint
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x070f
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.circleConstraint
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x056d
            r22 = r8
            r23 = r17
            r24 = r9
            r0 = r24
            float r0 = r0.circleAngle
            r24 = r0
            r25 = r9
            r0 = r25
            int r0 = r0.circleRadius
            r25 = r0
            r22.connectCircularConstraint(r23, r24, r25)
        L_0x056d:
            r22 = r3
            if (r22 == 0) goto L_0x05a6
            r22 = r9
            r0 = r22
            int r0 = r0.editorAbsoluteX
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x0591
            r22 = r9
            r0 = r22
            int r0 = r0.editorAbsoluteY
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x05a6
        L_0x0591:
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.editorAbsoluteX
            r23 = r0
            r24 = r9
            r0 = r24
            int r0 = r0.editorAbsoluteY
            r24 = r0
            r22.setOrigin(r23, r24)
        L_0x05a6:
            r22 = r9
            r0 = r22
            boolean r0 = r0.horizontalDimensionFixed
            r22 = r0
            if (r22 != 0) goto L_0x09c1
            r22 = r9
            r0 = r22
            int r0 = r0.width
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x09b1
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_PARENT
            r22.setHorizontalDimensionBehaviour(r23)
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r23 = r9
            r0 = r23
            int r0 = r0.leftMargin
            r23 = r0
            r0 = r23
            r1 = r22
            r1.mMargin = r0
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r23 = r9
            r0 = r23
            int r0 = r0.rightMargin
            r23 = r0
            r0 = r23
            r1 = r22
            r1.mMargin = r0
        L_0x05f3:
            r22 = r9
            r0 = r22
            boolean r0 = r0.verticalDimensionFixed
            r22 = r0
            if (r22 != 0) goto L_0x09e7
            r22 = r9
            r0 = r22
            int r0 = r0.height
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 != r1) goto L_0x09d7
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_PARENT
            r22.setVerticalDimensionBehaviour(r23)
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r23 = r9
            r0 = r23
            int r0 = r0.topMargin
            r23 = r0
            r0 = r23
            r1 = r22
            r1.mMargin = r0
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r23 = r9
            r0 = r23
            int r0 = r0.bottomMargin
            r23 = r0
            r0 = r23
            r1 = r22
            r1.mMargin = r0
        L_0x0640:
            r22 = r9
            r0 = r22
            java.lang.String r0 = r0.dimensionRatio
            r22 = r0
            if (r22 == 0) goto L_0x0657
            r22 = r8
            r23 = r9
            r0 = r23
            java.lang.String r0 = r0.dimensionRatio
            r23 = r0
            r22.setDimensionRatio(r23)
        L_0x0657:
            r22 = r8
            r23 = r9
            r0 = r23
            float r0 = r0.horizontalWeight
            r23 = r0
            r22.setHorizontalWeight(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            float r0 = r0.verticalWeight
            r23 = r0
            r22.setVerticalWeight(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.horizontalChainStyle
            r23 = r0
            r22.setHorizontalChainStyle(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.verticalChainStyle
            r23 = r0
            r22.setVerticalChainStyle(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.matchConstraintDefaultWidth
            r23 = r0
            r24 = r9
            r0 = r24
            int r0 = r0.matchConstraintMinWidth
            r24 = r0
            r25 = r9
            r0 = r25
            int r0 = r0.matchConstraintMaxWidth
            r25 = r0
            r26 = r9
            r0 = r26
            float r0 = r0.matchConstraintPercentWidth
            r26 = r0
            r22.setHorizontalMatchStyle(r23, r24, r25, r26)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.matchConstraintDefaultHeight
            r23 = r0
            r24 = r9
            r0 = r24
            int r0 = r0.matchConstraintMinHeight
            r24 = r0
            r25 = r9
            r0 = r25
            int r0 = r0.matchConstraintMaxHeight
            r25 = r0
            r26 = r9
            r0 = r26
            float r0 = r0.matchConstraintPercentHeight
            r26 = r0
            r22.setVerticalMatchStyle(r23, r24, r25, r26)
            goto L_0x01c7
        L_0x06d7:
            r22 = r9
            r0 = r22
            int r0 = r0.startToEnd
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0504
            r22 = r9
            r0 = r22
            int r0 = r0.startToEnd
            r22 = r0
            r11 = r22
            goto L_0x0504
        L_0x06f3:
            r22 = r9
            r0 = r22
            int r0 = r0.endToEnd
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0532
            r22 = r9
            r0 = r22
            int r0 = r0.endToEnd
            r22 = r0
            r13 = r22
            goto L_0x0532
        L_0x070f:
            r22 = r10
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x08d1
            r22 = r2
            r23 = r10
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x073c
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r26 = r9
            r0 = r26
            int r0 = r0.leftMargin
            r26 = r0
            r27 = r14
            r22.immediateConnect(r23, r24, r25, r26, r27)
        L_0x073c:
            r22 = r12
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0900
            r22 = r2
            r23 = r12
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x0769
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r26 = r9
            r0 = r26
            int r0 = r0.rightMargin
            r26 = r0
            r27 = r15
            r22.immediateConnect(r23, r24, r25, r26, r27)
        L_0x0769:
            r22 = r9
            r0 = r22
            int r0 = r0.topToTop
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x092f
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.topToTop
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x07a8
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            r26 = r9
            r0 = r26
            int r0 = r0.topMargin
            r26 = r0
            r27 = r9
            r0 = r27
            int r0 = r0.goneTopMargin
            r27 = r0
            r22.immediateConnect(r23, r24, r25, r26, r27)
        L_0x07a8:
            r22 = r9
            r0 = r22
            int r0 = r0.bottomToTop
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0970
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.bottomToTop
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x07e7
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            r26 = r9
            r0 = r26
            int r0 = r0.bottomMargin
            r26 = r0
            r27 = r9
            r0 = r27
            int r0 = r0.goneBottomMargin
            r27 = r0
            r22.immediateConnect(r23, r24, r25, r26, r27)
        L_0x07e7:
            r22 = r9
            r0 = r22
            int r0 = r0.baselineToBaseline
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x088f
            r22 = r2
            r0 = r22
            android.util.SparseArray<android.view.View> r0 = r0.mChildrenByIds
            r22 = r0
            r23 = r9
            r0 = r23
            int r0 = r0.baselineToBaseline
            r23 = r0
            java.lang.Object r22 = r22.get(r23)
            android.view.View r22 = (android.view.View) r22
            r17 = r22
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.baselineToBaseline
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r18 = r22
            r22 = r18
            if (r22 == 0) goto L_0x088f
            r22 = r17
            if (r22 == 0) goto L_0x088f
            r22 = r17
            android.view.ViewGroup$LayoutParams r22 = r22.getLayoutParams()
            r0 = r22
            boolean r0 = r0 instanceof android.support.constraint.ConstraintLayout.LayoutParams
            r22 = r0
            if (r22 == 0) goto L_0x088f
            r22 = r17
            android.view.ViewGroup$LayoutParams r22 = r22.getLayoutParams()
            android.support.constraint.ConstraintLayout$LayoutParams r22 = (android.support.constraint.ConstraintLayout.LayoutParams) r22
            r19 = r22
            r22 = r9
            r23 = 1
            r0 = r23
            r1 = r22
            r1.needsBaseline = r0
            r22 = r19
            r23 = 1
            r0 = r23
            r1 = r22
            r1.needsBaseline = r0
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BASELINE
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r20 = r22
            r22 = r18
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BASELINE
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r21 = r22
            r22 = r20
            r23 = r21
            r24 = 0
            r25 = -1
            android.support.constraint.solver.widgets.ConstraintAnchor$Strength r26 = android.support.constraint.solver.widgets.ConstraintAnchor.Strength.STRONG
            r27 = 0
            r28 = 1
            boolean r22 = r22.connect(r23, r24, r25, r26, r27, r28)
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r22.reset()
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            android.support.constraint.solver.widgets.ConstraintAnchor r22 = r22.getAnchor(r23)
            r22.reset()
        L_0x088f:
            r22 = r16
            r23 = 0
            int r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1))
            if (r22 < 0) goto L_0x08a6
            r22 = r16
            r23 = 1056964608(0x3f000000, float:0.5)
            int r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1))
            if (r22 == 0) goto L_0x08a6
            r22 = r8
            r23 = r16
            r22.setHorizontalBiasPercent(r23)
        L_0x08a6:
            r22 = r9
            r0 = r22
            float r0 = r0.verticalBias
            r22 = r0
            r23 = 0
            int r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1))
            if (r22 < 0) goto L_0x056d
            r22 = r9
            r0 = r22
            float r0 = r0.verticalBias
            r22 = r0
            r23 = 1056964608(0x3f000000, float:0.5)
            int r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1))
            if (r22 == 0) goto L_0x056d
            r22 = r8
            r23 = r9
            r0 = r23
            float r0 = r0.verticalBias
            r23 = r0
            r22.setVerticalBiasPercent(r23)
            goto L_0x056d
        L_0x08d1:
            r22 = r11
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x073c
            r22 = r2
            r23 = r11
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x073c
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.LEFT
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r26 = r9
            r0 = r26
            int r0 = r0.leftMargin
            r26 = r0
            r27 = r14
            r22.immediateConnect(r23, r24, r25, r26, r27)
            goto L_0x073c
        L_0x0900:
            r22 = r13
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x0769
            r22 = r2
            r23 = r13
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x0769
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.RIGHT
            r26 = r9
            r0 = r26
            int r0 = r0.rightMargin
            r26 = r0
            r27 = r15
            r22.immediateConnect(r23, r24, r25, r26, r27)
            goto L_0x0769
        L_0x092f:
            r22 = r9
            r0 = r22
            int r0 = r0.topToBottom
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x07a8
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.topToBottom
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x07a8
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.TOP
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            r26 = r9
            r0 = r26
            int r0 = r0.topMargin
            r26 = r0
            r27 = r9
            r0 = r27
            int r0 = r0.goneTopMargin
            r27 = r0
            r22.immediateConnect(r23, r24, r25, r26, r27)
            goto L_0x07a8
        L_0x0970:
            r22 = r9
            r0 = r22
            int r0 = r0.bottomToBottom
            r22 = r0
            r23 = -1
            r0 = r22
            r1 = r23
            if (r0 == r1) goto L_0x07e7
            r22 = r2
            r23 = r9
            r0 = r23
            int r0 = r0.bottomToBottom
            r23 = r0
            android.support.constraint.solver.widgets.ConstraintWidget r22 = r22.getTargetWidget(r23)
            r17 = r22
            r22 = r17
            if (r22 == 0) goto L_0x07e7
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r23 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            r24 = r17
            android.support.constraint.solver.widgets.ConstraintAnchor$Type r25 = android.support.constraint.solver.widgets.ConstraintAnchor.Type.BOTTOM
            r26 = r9
            r0 = r26
            int r0 = r0.bottomMargin
            r26 = r0
            r27 = r9
            r0 = r27
            int r0 = r0.goneBottomMargin
            r27 = r0
            r22.immediateConnect(r23, r24, r25, r26, r27)
            goto L_0x07e7
        L_0x09b1:
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            r22.setHorizontalDimensionBehaviour(r23)
            r22 = r8
            r23 = 0
            r22.setWidth(r23)
            goto L_0x05f3
        L_0x09c1:
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r22.setHorizontalDimensionBehaviour(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.width
            r23 = r0
            r22.setWidth(r23)
            goto L_0x05f3
        L_0x09d7:
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            r22.setVerticalDimensionBehaviour(r23)
            r22 = r8
            r23 = 0
            r22.setHeight(r23)
            goto L_0x0640
        L_0x09e7:
            r22 = r8
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r23 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.FIXED
            r22.setVerticalDimensionBehaviour(r23)
            r22 = r8
            r23 = r9
            r0 = r23
            int r0 = r0.height
            r23 = r0
            r22.setHeight(r23)
            goto L_0x0640
        L_0x09fd:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.ConstraintLayout.setChildrenConstraints():void");
    }

    private final ConstraintWidget getTargetWidget(int i) {
        int id = i;
        if (id == 0) {
            return this.mLayoutWidget;
        }
        View view = (View) this.mChildrenByIds.get(id);
        if (view == null) {
            view = findViewById(id);
            if (!(view == null || view == this || view.getParent() != this)) {
                onViewAdded(view);
            }
        }
        if (view == this) {
            return this.mLayoutWidget;
        }
        return view == null ? null : ((LayoutParams) view.getLayoutParams()).widget;
    }

    public final ConstraintWidget getViewWidget(View view) {
        View view2 = view;
        if (view2 == this) {
            return this.mLayoutWidget;
        }
        return view2 == null ? null : ((LayoutParams) view2.getLayoutParams()).widget;
    }

    private void internalMeasureChildren(int i, int i2) {
        int childWidthMeasureSpec;
        int childHeightMeasureSpec;
        int parentWidthSpec = i;
        int parentHeightSpec = i2;
        int heightPadding = getPaddingTop() + getPaddingBottom();
        int widthPadding = getPaddingLeft() + getPaddingRight();
        int widgetsCount = getChildCount();
        for (int i3 = 0; i3 < widgetsCount; i3++) {
            View child = getChildAt(i3);
            if (child.getVisibility() != 8) {
                LayoutParams params = (LayoutParams) child.getLayoutParams();
                ConstraintWidget widget = params.widget;
                if (!params.isGuideline && !params.isHelper) {
                    widget.setVisibility(child.getVisibility());
                    int width = params.width;
                    int height = params.height;
                    boolean didWrapMeasureWidth = false;
                    boolean didWrapMeasureHeight = false;
                    if (params.horizontalDimensionFixed || params.verticalDimensionFixed || (!params.horizontalDimensionFixed && params.matchConstraintDefaultWidth == 1) || params.width == -1 || (!params.verticalDimensionFixed && (params.matchConstraintDefaultHeight == 1 || params.height == -1))) {
                        if (width == 0) {
                            childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, -2);
                            didWrapMeasureWidth = true;
                        } else if (width == -1) {
                            childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, -1);
                        } else {
                            if (width == -2) {
                                didWrapMeasureWidth = true;
                            }
                            childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, width);
                        }
                        if (height == 0) {
                            childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, -2);
                            didWrapMeasureHeight = true;
                        } else if (height == -1) {
                            childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, -1);
                        } else {
                            if (height == -2) {
                                didWrapMeasureHeight = true;
                            }
                            childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, height);
                        }
                        child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
                        if (this.mMetrics != null) {
                            this.mMetrics.measures++;
                        }
                        widget.setWidthWrapContent(width == -2);
                        widget.setHeightWrapContent(height == -2);
                        width = child.getMeasuredWidth();
                        height = child.getMeasuredHeight();
                    }
                    widget.setWidth(width);
                    widget.setHeight(height);
                    if (didWrapMeasureWidth) {
                        widget.setWrapWidth(width);
                    }
                    if (didWrapMeasureHeight) {
                        widget.setWrapHeight(height);
                    }
                    if (params.needsBaseline) {
                        int baseline = child.getBaseline();
                        if (baseline != -1) {
                            widget.setBaselineDistance(baseline);
                        }
                    }
                }
            }
        }
    }

    private void updatePostMeasures() {
        int widgetsCount = getChildCount();
        for (int i = 0; i < widgetsCount; i++) {
            View child = getChildAt(i);
            if (child instanceof Placeholder) {
                ((Placeholder) child).updatePostMeasure(this);
            }
        }
        int helperCount = this.mConstraintHelpers.size();
        if (helperCount > 0) {
            for (int i2 = 0; i2 < helperCount; i2++) {
                ((ConstraintHelper) this.mConstraintHelpers.get(i2)).updatePostMeasure(this);
            }
        }
    }

    private void internalMeasureDimensions(int i, int i2) {
        int childWidthMeasureSpec;
        int childHeightMeasureSpec;
        int parentWidthSpec = i;
        int parentHeightSpec = i2;
        int heightPadding = getPaddingTop() + getPaddingBottom();
        int widthPadding = getPaddingLeft() + getPaddingRight();
        int widgetsCount = getChildCount();
        for (int i3 = 0; i3 < widgetsCount; i3++) {
            View child = getChildAt(i3);
            if (child.getVisibility() != 8) {
                LayoutParams params = (LayoutParams) child.getLayoutParams();
                ConstraintWidget widget = params.widget;
                if (!params.isGuideline && !params.isHelper) {
                    widget.setVisibility(child.getVisibility());
                    int width = params.width;
                    int height = params.height;
                    if (width == 0 || height == 0) {
                        widget.getResolutionWidth().invalidate();
                        widget.getResolutionHeight().invalidate();
                    } else {
                        boolean didWrapMeasureWidth = false;
                        boolean didWrapMeasureHeight = false;
                        if (width == -2) {
                            didWrapMeasureWidth = true;
                        }
                        int childWidthMeasureSpec2 = getChildMeasureSpec(parentWidthSpec, widthPadding, width);
                        if (height == -2) {
                            didWrapMeasureHeight = true;
                        }
                        child.measure(childWidthMeasureSpec2, getChildMeasureSpec(parentHeightSpec, heightPadding, height));
                        if (this.mMetrics != null) {
                            this.mMetrics.measures++;
                        }
                        widget.setWidthWrapContent(width == -2);
                        widget.setHeightWrapContent(height == -2);
                        int width2 = child.getMeasuredWidth();
                        int height2 = child.getMeasuredHeight();
                        widget.setWidth(width2);
                        widget.setHeight(height2);
                        if (didWrapMeasureWidth) {
                            widget.setWrapWidth(width2);
                        }
                        if (didWrapMeasureHeight) {
                            widget.setWrapHeight(height2);
                        }
                        if (params.needsBaseline) {
                            int baseline = child.getBaseline();
                            if (baseline != -1) {
                                widget.setBaselineDistance(baseline);
                            }
                        }
                        if (params.horizontalDimensionFixed && params.verticalDimensionFixed) {
                            widget.getResolutionWidth().resolve(width2);
                            widget.getResolutionHeight().resolve(height2);
                        }
                    }
                }
            }
        }
        this.mLayoutWidget.solveGraph();
        for (int i4 = 0; i4 < widgetsCount; i4++) {
            View child2 = getChildAt(i4);
            if (child2.getVisibility() != 8) {
                LayoutParams params2 = (LayoutParams) child2.getLayoutParams();
                ConstraintWidget widget2 = params2.widget;
                if (!params2.isGuideline && !params2.isHelper) {
                    widget2.setVisibility(child2.getVisibility());
                    int width3 = params2.width;
                    int height3 = params2.height;
                    if (width3 == 0 || height3 == 0) {
                        ResolutionAnchor left = widget2.getAnchor(Type.LEFT).getResolutionNode();
                        ResolutionAnchor right = widget2.getAnchor(Type.RIGHT).getResolutionNode();
                        boolean bothHorizontal = (widget2.getAnchor(Type.LEFT).getTarget() == null || widget2.getAnchor(Type.RIGHT).getTarget() == null) ? false : true;
                        ResolutionAnchor top = widget2.getAnchor(Type.TOP).getResolutionNode();
                        ResolutionAnchor bottom = widget2.getAnchor(Type.BOTTOM).getResolutionNode();
                        boolean bothVertical = (widget2.getAnchor(Type.TOP).getTarget() == null || widget2.getAnchor(Type.BOTTOM).getTarget() == null) ? false : true;
                        if (width3 != 0 || height3 != 0 || !bothHorizontal || !bothVertical) {
                            boolean didWrapMeasureWidth2 = false;
                            boolean didWrapMeasureHeight2 = false;
                            boolean resolveWidth = this.mLayoutWidget.getHorizontalDimensionBehaviour() != DimensionBehaviour.WRAP_CONTENT;
                            boolean resolveHeight = this.mLayoutWidget.getVerticalDimensionBehaviour() != DimensionBehaviour.WRAP_CONTENT;
                            if (!resolveWidth) {
                                widget2.getResolutionWidth().invalidate();
                            }
                            if (!resolveHeight) {
                                widget2.getResolutionHeight().invalidate();
                            }
                            if (width3 == 0) {
                                if (!resolveWidth || !widget2.isSpreadWidth() || !bothHorizontal || !left.isResolved() || !right.isResolved()) {
                                    childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, -2);
                                    didWrapMeasureWidth2 = true;
                                    resolveWidth = false;
                                } else {
                                    width3 = (int) (right.getResolvedValue() - left.getResolvedValue());
                                    widget2.getResolutionWidth().resolve(width3);
                                    childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, width3);
                                }
                            } else if (width3 == -1) {
                                childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, -1);
                            } else {
                                if (width3 == -2) {
                                    didWrapMeasureWidth2 = true;
                                }
                                childWidthMeasureSpec = getChildMeasureSpec(parentWidthSpec, widthPadding, width3);
                            }
                            if (height3 == 0) {
                                if (!resolveHeight || !widget2.isSpreadHeight() || !bothVertical || !top.isResolved() || !bottom.isResolved()) {
                                    childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, -2);
                                    didWrapMeasureHeight2 = true;
                                    resolveHeight = false;
                                } else {
                                    height3 = (int) (bottom.getResolvedValue() - top.getResolvedValue());
                                    widget2.getResolutionHeight().resolve(height3);
                                    childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, height3);
                                }
                            } else if (height3 == -1) {
                                childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, -1);
                            } else {
                                if (height3 == -2) {
                                    didWrapMeasureHeight2 = true;
                                }
                                childHeightMeasureSpec = getChildMeasureSpec(parentHeightSpec, heightPadding, height3);
                            }
                            child2.measure(childWidthMeasureSpec, childHeightMeasureSpec);
                            if (this.mMetrics != null) {
                                this.mMetrics.measures++;
                            }
                            widget2.setWidthWrapContent(width3 == -2);
                            widget2.setHeightWrapContent(height3 == -2);
                            int width4 = child2.getMeasuredWidth();
                            int height4 = child2.getMeasuredHeight();
                            widget2.setWidth(width4);
                            widget2.setHeight(height4);
                            if (didWrapMeasureWidth2) {
                                widget2.setWrapWidth(width4);
                            }
                            if (didWrapMeasureHeight2) {
                                widget2.setWrapHeight(height4);
                            }
                            if (resolveWidth) {
                                widget2.getResolutionWidth().resolve(width4);
                            } else {
                                widget2.getResolutionWidth().remove();
                            }
                            if (resolveHeight) {
                                widget2.getResolutionHeight().resolve(height4);
                            } else {
                                widget2.getResolutionHeight().remove();
                            }
                            if (params2.needsBaseline) {
                                int baseline2 = child2.getBaseline();
                                if (baseline2 != -1) {
                                    widget2.setBaselineDistance(baseline2);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void fillMetrics(Metrics metrics) {
        Metrics metrics2 = metrics;
        this.mMetrics = metrics2;
        this.mLayoutWidget.fillMetrics(metrics2);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int widthSpec;
        int heightSpec;
        int widthMeasureSpec = i;
        int heightMeasureSpec = i2;
        long currentTimeMillis = System.currentTimeMillis();
        int REMEASURES_A = 0;
        int REMEASURES_B = 0;
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        this.mLayoutWidget.setX(paddingLeft);
        this.mLayoutWidget.setY(paddingTop);
        this.mLayoutWidget.setMaxWidth(this.mMaxWidth);
        this.mLayoutWidget.setMaxHeight(this.mMaxHeight);
        if (VERSION.SDK_INT >= 17) {
            this.mLayoutWidget.setRtl(getLayoutDirection() == 1);
        }
        setSelfDimensionBehaviour(widthMeasureSpec, heightMeasureSpec);
        int startingWidth = this.mLayoutWidget.getWidth();
        int startingHeight = this.mLayoutWidget.getHeight();
        boolean runAnalyzer = false;
        if (this.mDirtyHierarchy) {
            this.mDirtyHierarchy = false;
            updateHierarchy();
            runAnalyzer = true;
        }
        boolean optimiseDimensions = (this.mOptimizationLevel & 8) == 8;
        if (optimiseDimensions) {
            this.mLayoutWidget.preOptimize();
            this.mLayoutWidget.optimizeForDimensions(startingWidth, startingHeight);
            internalMeasureDimensions(widthMeasureSpec, heightMeasureSpec);
        } else {
            internalMeasureChildren(widthMeasureSpec, heightMeasureSpec);
        }
        updatePostMeasures();
        if (getChildCount() > 0 && runAnalyzer) {
            Analyzer.determineGroups(this.mLayoutWidget);
        }
        if (this.mLayoutWidget.mGroupsWrapOptimized) {
            if (this.mLayoutWidget.mHorizontalWrapOptimized && widthMode == Integer.MIN_VALUE) {
                if (this.mLayoutWidget.mWrapFixedWidth < widthSize) {
                    this.mLayoutWidget.setWidth(this.mLayoutWidget.mWrapFixedWidth);
                }
                this.mLayoutWidget.setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
            }
            if (this.mLayoutWidget.mVerticalWrapOptimized && heightMode == Integer.MIN_VALUE) {
                if (this.mLayoutWidget.mWrapFixedHeight < heightSize) {
                    this.mLayoutWidget.setHeight(this.mLayoutWidget.mWrapFixedHeight);
                }
                this.mLayoutWidget.setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
            }
        }
        if ((this.mOptimizationLevel & 32) == 32) {
            int width = this.mLayoutWidget.getWidth();
            int height = this.mLayoutWidget.getHeight();
            if (this.mLastMeasureWidth != width && widthMode == 1073741824) {
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, width);
            }
            if (this.mLastMeasureHeight != height && heightMode == 1073741824) {
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, height);
            }
            if (this.mLayoutWidget.mHorizontalWrapOptimized) {
                if (this.mLayoutWidget.mWrapFixedWidth > widthSize) {
                    Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, widthSize);
                }
            }
            if (this.mLayoutWidget.mVerticalWrapOptimized) {
                if (this.mLayoutWidget.mWrapFixedHeight > heightSize) {
                    Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, heightSize);
                }
            }
        }
        if (getChildCount() > 0) {
            solveLinearSystem("First pass");
        }
        int childState = 0;
        int sizeDependentWidgetsCount = this.mVariableDimensionsWidgets.size();
        int heightPadding = paddingTop + getPaddingBottom();
        int widthPadding = paddingLeft + getPaddingRight();
        if (sizeDependentWidgetsCount > 0) {
            boolean needSolverPass = false;
            boolean containerWrapWidth = this.mLayoutWidget.getHorizontalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT;
            boolean containerWrapHeight = this.mLayoutWidget.getVerticalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT;
            int minWidth = Math.max(this.mLayoutWidget.getWidth(), this.mMinWidth);
            int minHeight = Math.max(this.mLayoutWidget.getHeight(), this.mMinHeight);
            for (int i3 = 0; i3 < sizeDependentWidgetsCount; i3++) {
                ConstraintWidget widget = (ConstraintWidget) this.mVariableDimensionsWidgets.get(i3);
                View child = (View) widget.getCompanionWidget();
                if (child != null) {
                    LayoutParams params = (LayoutParams) child.getLayoutParams();
                    if (!params.isHelper && !params.isGuideline && child.getVisibility() != 8 && (!optimiseDimensions || !widget.getResolutionWidth().isResolved() || !widget.getResolutionHeight().isResolved())) {
                        if (params.width != -2 || !params.horizontalDimensionFixed) {
                            widthSpec = MeasureSpec.makeMeasureSpec(widget.getWidth(), Declaration.MODULE_REFERENCE);
                        } else {
                            widthSpec = getChildMeasureSpec(widthMeasureSpec, widthPadding, params.width);
                        }
                        if (params.height != -2 || !params.verticalDimensionFixed) {
                            heightSpec = MeasureSpec.makeMeasureSpec(widget.getHeight(), Declaration.MODULE_REFERENCE);
                        } else {
                            heightSpec = getChildMeasureSpec(heightMeasureSpec, heightPadding, params.height);
                        }
                        child.measure(widthSpec, heightSpec);
                        if (this.mMetrics != null) {
                            this.mMetrics.additionalMeasures++;
                        }
                        REMEASURES_A++;
                        int measuredWidth = child.getMeasuredWidth();
                        int measuredHeight = child.getMeasuredHeight();
                        if (measuredWidth != widget.getWidth()) {
                            widget.setWidth(measuredWidth);
                            if (optimiseDimensions) {
                                widget.getResolutionWidth().resolve(measuredWidth);
                            }
                            if (containerWrapWidth && widget.getRight() > minWidth) {
                                minWidth = Math.max(minWidth, widget.getRight() + widget.getAnchor(Type.RIGHT).getMargin());
                            }
                            needSolverPass = true;
                        }
                        if (measuredHeight != widget.getHeight()) {
                            widget.setHeight(measuredHeight);
                            if (optimiseDimensions) {
                                widget.getResolutionHeight().resolve(measuredHeight);
                            }
                            if (containerWrapHeight && widget.getBottom() > minHeight) {
                                minHeight = Math.max(minHeight, widget.getBottom() + widget.getAnchor(Type.BOTTOM).getMargin());
                            }
                            needSolverPass = true;
                        }
                        if (params.needsBaseline) {
                            int baseline = child.getBaseline();
                            if (!(baseline == -1 || baseline == widget.getBaselineDistance())) {
                                widget.setBaselineDistance(baseline);
                                needSolverPass = true;
                            }
                        }
                        if (VERSION.SDK_INT >= 11) {
                            childState = combineMeasuredStates(childState, child.getMeasuredState());
                        }
                    }
                }
            }
            if (needSolverPass) {
                this.mLayoutWidget.setWidth(startingWidth);
                this.mLayoutWidget.setHeight(startingHeight);
                if (optimiseDimensions) {
                    this.mLayoutWidget.solveGraph();
                }
                solveLinearSystem("2nd pass");
                boolean needSolverPass2 = false;
                if (this.mLayoutWidget.getWidth() < minWidth) {
                    this.mLayoutWidget.setWidth(minWidth);
                    needSolverPass2 = true;
                }
                if (this.mLayoutWidget.getHeight() < minHeight) {
                    this.mLayoutWidget.setHeight(minHeight);
                    needSolverPass2 = true;
                }
                if (needSolverPass2) {
                    solveLinearSystem("3rd pass");
                }
            }
            for (int i4 = 0; i4 < sizeDependentWidgetsCount; i4++) {
                ConstraintWidget widget2 = (ConstraintWidget) this.mVariableDimensionsWidgets.get(i4);
                View child2 = (View) widget2.getCompanionWidget();
                if (!(child2 == null || ((child2.getMeasuredWidth() == widget2.getWidth() && child2.getMeasuredHeight() == widget2.getHeight()) || widget2.getVisibility() == 8))) {
                    child2.measure(MeasureSpec.makeMeasureSpec(widget2.getWidth(), Declaration.MODULE_REFERENCE), MeasureSpec.makeMeasureSpec(widget2.getHeight(), Declaration.MODULE_REFERENCE));
                    if (this.mMetrics != null) {
                        this.mMetrics.additionalMeasures++;
                    }
                    REMEASURES_B++;
                }
            }
        }
        int androidLayoutWidth = this.mLayoutWidget.getWidth() + widthPadding;
        int androidLayoutHeight = this.mLayoutWidget.getHeight() + heightPadding;
        if (VERSION.SDK_INT >= 11) {
            int resolvedHeightSize = resolveSizeAndState(androidLayoutHeight, heightMeasureSpec, childState << 16) & 16777215;
            int resolvedWidthSize = Math.min(this.mMaxWidth, resolveSizeAndState(androidLayoutWidth, widthMeasureSpec, childState) & 16777215);
            int resolvedHeightSize2 = Math.min(this.mMaxHeight, resolvedHeightSize);
            if (this.mLayoutWidget.isWidthMeasuredTooSmall()) {
                resolvedWidthSize |= 16777216;
            }
            if (this.mLayoutWidget.isHeightMeasuredTooSmall()) {
                resolvedHeightSize2 |= 16777216;
            }
            setMeasuredDimension(resolvedWidthSize, resolvedHeightSize2);
            this.mLastMeasureWidth = resolvedWidthSize;
            this.mLastMeasureHeight = resolvedHeightSize2;
            return;
        }
        setMeasuredDimension(androidLayoutWidth, androidLayoutHeight);
        this.mLastMeasureWidth = androidLayoutWidth;
        this.mLastMeasureHeight = androidLayoutHeight;
    }

    private void setSelfDimensionBehaviour(int i, int i2) {
        int widthMeasureSpec = i;
        int heightMeasureSpec = i2;
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int heightPadding = getPaddingTop() + getPaddingBottom();
        int widthPadding = getPaddingLeft() + getPaddingRight();
        DimensionBehaviour widthBehaviour = DimensionBehaviour.FIXED;
        DimensionBehaviour heightBehaviour = DimensionBehaviour.FIXED;
        int desiredWidth = 0;
        int desiredHeight = 0;
        android.view.ViewGroup.LayoutParams layoutParams = getLayoutParams();
        switch (widthMode) {
            case Integer.MIN_VALUE:
                widthBehaviour = DimensionBehaviour.WRAP_CONTENT;
                desiredWidth = widthSize;
                break;
            case 0:
                widthBehaviour = DimensionBehaviour.WRAP_CONTENT;
                break;
            case Declaration.MODULE_REFERENCE /*1073741824*/:
                desiredWidth = Math.min(this.mMaxWidth, widthSize) - widthPadding;
                break;
        }
        switch (heightMode) {
            case Integer.MIN_VALUE:
                heightBehaviour = DimensionBehaviour.WRAP_CONTENT;
                desiredHeight = heightSize;
                break;
            case 0:
                heightBehaviour = DimensionBehaviour.WRAP_CONTENT;
                break;
            case Declaration.MODULE_REFERENCE /*1073741824*/:
                desiredHeight = Math.min(this.mMaxHeight, heightSize) - heightPadding;
                break;
        }
        this.mLayoutWidget.setMinWidth(0);
        this.mLayoutWidget.setMinHeight(0);
        this.mLayoutWidget.setHorizontalDimensionBehaviour(widthBehaviour);
        this.mLayoutWidget.setWidth(desiredWidth);
        this.mLayoutWidget.setVerticalDimensionBehaviour(heightBehaviour);
        this.mLayoutWidget.setHeight(desiredHeight);
        this.mLayoutWidget.setMinWidth((this.mMinWidth - getPaddingLeft()) - getPaddingRight());
        this.mLayoutWidget.setMinHeight((this.mMinHeight - getPaddingTop()) - getPaddingBottom());
    }

    /* access modifiers changed from: protected */
    public void solveLinearSystem(String str) {
        String str2 = str;
        this.mLayoutWidget.layout();
        if (this.mMetrics != null) {
            this.mMetrics.resolutions++;
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2 = z;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        int widgetsCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i9 = 0; i9 < widgetsCount; i9++) {
            View child = getChildAt(i9);
            LayoutParams params = (LayoutParams) child.getLayoutParams();
            ConstraintWidget widget = params.widget;
            if ((child.getVisibility() != 8 || params.isGuideline || params.isHelper || isInEditMode) && !params.isInPlaceholder) {
                int l = widget.getDrawX();
                int t = widget.getDrawY();
                int r = l + widget.getWidth();
                int b = t + widget.getHeight();
                child.layout(l, t, r, b);
                if (child instanceof Placeholder) {
                    View content = ((Placeholder) child).getContent();
                    if (content != null) {
                        content.setVisibility(0);
                        content.layout(l, t, r, b);
                    }
                }
            }
        }
        int helperCount = this.mConstraintHelpers.size();
        if (helperCount > 0) {
            for (int i10 = 0; i10 < helperCount; i10++) {
                ((ConstraintHelper) this.mConstraintHelpers.get(i10)).updatePostLayout(this);
            }
        }
    }

    public void setOptimizationLevel(int i) {
        int level = i;
        this.mLayoutWidget.setOptimizationLevel(level);
    }

    public int getOptimizationLevel() {
        return this.mLayoutWidget.getOptimizationLevel();
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        LayoutParams layoutParams;
        AttributeSet attrs = attributeSet;
        LayoutParams layoutParams2 = layoutParams;
        LayoutParams layoutParams3 = new LayoutParams(getContext(), attrs);
        return layoutParams2;
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams;
        LayoutParams layoutParams2 = layoutParams;
        LayoutParams layoutParams3 = new LayoutParams(-2, -2);
        return layoutParams2;
    }

    /* access modifiers changed from: protected */
    public android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        LayoutParams layoutParams2;
        LayoutParams layoutParams3 = layoutParams2;
        LayoutParams layoutParams4 = new LayoutParams(layoutParams);
        return layoutParams3;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public void setConstraintSet(ConstraintSet constraintSet) {
        ConstraintSet constraintSet2 = constraintSet;
        this.mConstraintSet = constraintSet2;
    }

    public View getViewById(int i) {
        return (View) this.mChildrenByIds.get(i);
    }

    public void dispatchDraw(Canvas canvas) {
        Paint paint;
        Canvas canvas2 = canvas;
        super.dispatchDraw(canvas2);
        if (isInEditMode()) {
            int count = getChildCount();
            float cw = (float) getWidth();
            float ch = (float) getHeight();
            for (int i = 0; i < count; i++) {
                View child = getChildAt(i);
                if (child.getVisibility() != 8) {
                    Object tag = child.getTag();
                    if (tag != null && (tag instanceof String)) {
                        String[] split = ((String) tag).split(",");
                        if (split.length == 4) {
                            int x = Integer.parseInt(split[0]);
                            int y = Integer.parseInt(split[1]);
                            int w = Integer.parseInt(split[2]);
                            int x2 = (int) ((((float) x) / 1080.0f) * cw);
                            int y2 = (int) ((((float) y) / 1920.0f) * ch);
                            int w2 = (int) ((((float) w) / 1080.0f) * cw);
                            int h = (int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * ch);
                            Paint paint2 = paint;
                            Paint paint3 = new Paint();
                            Paint paint4 = paint2;
                            paint4.setColor(SupportMenu.CATEGORY_MASK);
                            canvas2.drawLine((float) x2, (float) y2, (float) (x2 + w2), (float) y2, paint4);
                            canvas2.drawLine((float) (x2 + w2), (float) y2, (float) (x2 + w2), (float) (y2 + h), paint4);
                            canvas2.drawLine((float) (x2 + w2), (float) (y2 + h), (float) x2, (float) (y2 + h), paint4);
                            canvas2.drawLine((float) x2, (float) (y2 + h), (float) x2, (float) y2, paint4);
                            paint4.setColor(-16711936);
                            canvas2.drawLine((float) x2, (float) y2, (float) (x2 + w2), (float) (y2 + h), paint4);
                            canvas2.drawLine((float) x2, (float) (y2 + h), (float) (x2 + w2), (float) y2, paint4);
                        }
                    }
                }
            }
        }
    }

    public void requestLayout() {
        super.requestLayout();
        this.mDirtyHierarchy = true;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
