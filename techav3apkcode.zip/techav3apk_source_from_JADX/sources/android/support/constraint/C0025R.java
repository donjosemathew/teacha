package android.support.constraint;

import techa.hackathon.com.R;

/* renamed from: android.support.constraint.R */
public final class C0025R {

    /* renamed from: android.support.constraint.R$attr */
    public static final class attr {
        public static final int barrierAllowsGoneWidgets = 2130771968;
        public static final int barrierDirection = 2130771969;
        public static final int chainUseRtl = 2130771975;
        public static final int constraintSet = 2130771980;
        public static final int constraint_referenced_ids = 2130771981;
        public static final int content = 2130771982;
        public static final int emptyVisibility = 2130771985;
        public static final int layout_constrainedHeight = 2130771990;
        public static final int layout_constrainedWidth = 2130771991;
        public static final int layout_constraintBaseline_creator = 2130771992;
        public static final int layout_constraintBaseline_toBaselineOf = 2130771993;
        public static final int layout_constraintBottom_creator = 2130771994;
        public static final int layout_constraintBottom_toBottomOf = 2130771995;
        public static final int layout_constraintBottom_toTopOf = 2130771996;
        public static final int layout_constraintCircle = 2130771997;
        public static final int layout_constraintCircleAngle = 2130771998;
        public static final int layout_constraintCircleRadius = 2130771999;
        public static final int layout_constraintDimensionRatio = 2130772000;
        public static final int layout_constraintEnd_toEndOf = 2130772001;
        public static final int layout_constraintEnd_toStartOf = 2130772002;
        public static final int layout_constraintGuide_begin = 2130772003;
        public static final int layout_constraintGuide_end = 2130772004;
        public static final int layout_constraintGuide_percent = 2130772005;
        public static final int layout_constraintHeight_default = 2130772006;
        public static final int layout_constraintHeight_max = 2130772007;
        public static final int layout_constraintHeight_min = 2130772008;
        public static final int layout_constraintHeight_percent = 2130772009;
        public static final int layout_constraintHorizontal_bias = 2130772010;
        public static final int layout_constraintHorizontal_chainStyle = 2130772011;
        public static final int layout_constraintHorizontal_weight = 2130772012;
        public static final int layout_constraintLeft_creator = 2130772013;
        public static final int layout_constraintLeft_toLeftOf = 2130772014;
        public static final int layout_constraintLeft_toRightOf = 2130772015;
        public static final int layout_constraintRight_creator = 2130772016;
        public static final int layout_constraintRight_toLeftOf = 2130772017;
        public static final int layout_constraintRight_toRightOf = 2130772018;
        public static final int layout_constraintStart_toEndOf = 2130772019;
        public static final int layout_constraintStart_toStartOf = 2130772020;
        public static final int layout_constraintTop_creator = 2130772021;
        public static final int layout_constraintTop_toBottomOf = 2130772022;
        public static final int layout_constraintTop_toTopOf = 2130772023;
        public static final int layout_constraintVertical_bias = 2130772024;
        public static final int layout_constraintVertical_chainStyle = 2130772025;
        public static final int layout_constraintVertical_weight = 2130772026;
        public static final int layout_constraintWidth_default = 2130772027;
        public static final int layout_constraintWidth_max = 2130772028;
        public static final int layout_constraintWidth_min = 2130772029;
        public static final int layout_constraintWidth_percent = 2130772030;
        public static final int layout_editor_absoluteX = 2130772031;
        public static final int layout_editor_absoluteY = 2130772032;
        public static final int layout_goneMarginBottom = 2130772033;
        public static final int layout_goneMarginEnd = 2130772034;
        public static final int layout_goneMarginLeft = 2130772035;
        public static final int layout_goneMarginRight = 2130772036;
        public static final int layout_goneMarginStart = 2130772037;
        public static final int layout_goneMarginTop = 2130772038;
        public static final int layout_optimizationLevel = 2130772039;

        public attr() {
        }
    }

    /* renamed from: android.support.constraint.R$id */
    public static final class C0026id {
        public static final int bottom = 2131689508;
        public static final int end = 2131689509;
        public static final int gone = 2131689514;
        public static final int invisible = 2131689515;
        public static final int left = 2131689510;
        public static final int packed = 2131689520;
        public static final int parent = 2131689516;
        public static final int percent = 2131689517;
        public static final int right = 2131689511;
        public static final int spread = 2131689518;
        public static final int spread_inside = 2131689521;
        public static final int start = 2131689512;
        public static final int top = 2131689513;
        public static final int wrap = 2131689519;

        public C0026id() {
        }
    }

    /* renamed from: android.support.constraint.R$styleable */
    public static final class styleable {
        public static final int[] ConstraintLayout_Layout = {16842948, 16843039, 16843040, 16843071, 16843072, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.chainUseRtl, R.attr.constraintSet, R.attr.constraint_referenced_ids, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_optimizationLevel};
        public static final int ConstraintLayout_Layout_android_maxHeight = 2;
        public static final int ConstraintLayout_Layout_android_maxWidth = 1;
        public static final int ConstraintLayout_Layout_android_minHeight = 4;
        public static final int ConstraintLayout_Layout_android_minWidth = 3;
        public static final int ConstraintLayout_Layout_android_orientation = 0;
        public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
        public static final int ConstraintLayout_Layout_barrierDirection = 6;
        public static final int ConstraintLayout_Layout_chainUseRtl = 7;
        public static final int ConstraintLayout_Layout_constraintSet = 8;
        public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
        public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
        public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
        public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
        public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
        public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
        public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
        public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
        public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
        public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
        public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
        public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
        public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
        public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
        public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
        public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
        public static final int[] ConstraintLayout_placeholder = {R.attr.content, R.attr.emptyVisibility};
        public static final int ConstraintLayout_placeholder_content = 0;
        public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
        public static final int[] ConstraintSet = {16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop};
        public static final int ConstraintSet_android_alpha = 13;
        public static final int ConstraintSet_android_elevation = 26;
        public static final int ConstraintSet_android_id = 1;
        public static final int ConstraintSet_android_layout_height = 4;
        public static final int ConstraintSet_android_layout_marginBottom = 8;
        public static final int ConstraintSet_android_layout_marginEnd = 24;
        public static final int ConstraintSet_android_layout_marginLeft = 5;
        public static final int ConstraintSet_android_layout_marginRight = 7;
        public static final int ConstraintSet_android_layout_marginStart = 23;
        public static final int ConstraintSet_android_layout_marginTop = 6;
        public static final int ConstraintSet_android_layout_width = 3;
        public static final int ConstraintSet_android_maxHeight = 10;
        public static final int ConstraintSet_android_maxWidth = 9;
        public static final int ConstraintSet_android_minHeight = 12;
        public static final int ConstraintSet_android_minWidth = 11;
        public static final int ConstraintSet_android_orientation = 0;
        public static final int ConstraintSet_android_rotation = 20;
        public static final int ConstraintSet_android_rotationX = 21;
        public static final int ConstraintSet_android_rotationY = 22;
        public static final int ConstraintSet_android_scaleX = 18;
        public static final int ConstraintSet_android_scaleY = 19;
        public static final int ConstraintSet_android_transformPivotX = 14;
        public static final int ConstraintSet_android_transformPivotY = 15;
        public static final int ConstraintSet_android_translationX = 16;
        public static final int ConstraintSet_android_translationY = 17;
        public static final int ConstraintSet_android_translationZ = 25;
        public static final int ConstraintSet_android_visibility = 2;
        public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
        public static final int ConstraintSet_barrierDirection = 28;
        public static final int ConstraintSet_chainUseRtl = 29;
        public static final int ConstraintSet_constraint_referenced_ids = 30;
        public static final int ConstraintSet_layout_constrainedHeight = 31;
        public static final int ConstraintSet_layout_constrainedWidth = 32;
        public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
        public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
        public static final int ConstraintSet_layout_constraintBottom_creator = 35;
        public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
        public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
        public static final int ConstraintSet_layout_constraintCircle = 38;
        public static final int ConstraintSet_layout_constraintCircleAngle = 39;
        public static final int ConstraintSet_layout_constraintCircleRadius = 40;
        public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
        public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
        public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
        public static final int ConstraintSet_layout_constraintGuide_begin = 44;
        public static final int ConstraintSet_layout_constraintGuide_end = 45;
        public static final int ConstraintSet_layout_constraintGuide_percent = 46;
        public static final int ConstraintSet_layout_constraintHeight_default = 47;
        public static final int ConstraintSet_layout_constraintHeight_max = 48;
        public static final int ConstraintSet_layout_constraintHeight_min = 49;
        public static final int ConstraintSet_layout_constraintHeight_percent = 50;
        public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
        public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
        public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
        public static final int ConstraintSet_layout_constraintLeft_creator = 54;
        public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
        public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
        public static final int ConstraintSet_layout_constraintRight_creator = 57;
        public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
        public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
        public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
        public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
        public static final int ConstraintSet_layout_constraintTop_creator = 62;
        public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
        public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
        public static final int ConstraintSet_layout_constraintVertical_bias = 65;
        public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
        public static final int ConstraintSet_layout_constraintVertical_weight = 67;
        public static final int ConstraintSet_layout_constraintWidth_default = 68;
        public static final int ConstraintSet_layout_constraintWidth_max = 69;
        public static final int ConstraintSet_layout_constraintWidth_min = 70;
        public static final int ConstraintSet_layout_constraintWidth_percent = 71;
        public static final int ConstraintSet_layout_editor_absoluteX = 72;
        public static final int ConstraintSet_layout_editor_absoluteY = 73;
        public static final int ConstraintSet_layout_goneMarginBottom = 74;
        public static final int ConstraintSet_layout_goneMarginEnd = 75;
        public static final int ConstraintSet_layout_goneMarginLeft = 76;
        public static final int ConstraintSet_layout_goneMarginRight = 77;
        public static final int ConstraintSet_layout_goneMarginStart = 78;
        public static final int ConstraintSet_layout_goneMarginTop = 79;
        public static final int[] LinearConstraintLayout;
        public static final int LinearConstraintLayout_android_orientation = 0;

        public styleable() {
        }

        static {
            int[] iArr = new int[1];
            int[] iArr2 = iArr;
            iArr[0] = 16842948;
            LinearConstraintLayout = iArr2;
        }
    }

    public C0025R() {
    }
}
