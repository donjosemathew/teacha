package android.support.graphics.drawable;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.XmlResourceParser;
import android.os.Build.VERSION;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.p000v4.view.animation.FastOutLinearInInterpolator;
import android.support.p000v4.view.animation.FastOutSlowInInterpolator;
import android.support.p000v4.view.animation.LinearOutSlowInInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({Scope.LIBRARY_GROUP})
public class AnimationUtilsCompat {
    public static Interpolator loadInterpolator(Context context, int i) throws NotFoundException {
        NotFoundException notFoundException;
        StringBuilder sb;
        NotFoundException notFoundException2;
        StringBuilder sb2;
        LinearOutSlowInInterpolator linearOutSlowInInterpolator;
        FastOutSlowInInterpolator fastOutSlowInInterpolator;
        FastOutLinearInInterpolator fastOutLinearInInterpolator;
        Context context2 = context;
        int id = i;
        if (VERSION.SDK_INT >= 21) {
            return AnimationUtils.loadInterpolator(context2, id);
        }
        XmlResourceParser parser = null;
        if (id == 17563663) {
            try {
                FastOutLinearInInterpolator fastOutLinearInInterpolator2 = fastOutLinearInInterpolator;
                FastOutLinearInInterpolator fastOutLinearInInterpolator3 = new FastOutLinearInInterpolator();
                FastOutLinearInInterpolator fastOutLinearInInterpolator4 = fastOutLinearInInterpolator2;
                if (0 != 0) {
                    null.close();
                }
                return fastOutLinearInInterpolator4;
            } catch (XmlPullParserException e) {
                XmlPullParserException ex = e;
                NotFoundException notFoundException3 = notFoundException2;
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                NotFoundException notFoundException4 = new NotFoundException(sb3.append("Can't load animation resource ID #0x").append(Integer.toHexString(id)).toString());
                NotFoundException rnf = notFoundException3;
                Throwable initCause = rnf.initCause(ex);
                throw rnf;
            } catch (IOException e2) {
                IOException ex2 = e2;
                NotFoundException notFoundException5 = notFoundException;
                StringBuilder sb5 = sb;
                StringBuilder sb6 = new StringBuilder();
                NotFoundException notFoundException6 = new NotFoundException(sb5.append("Can't load animation resource ID #0x").append(Integer.toHexString(id)).toString());
                NotFoundException rnf2 = notFoundException5;
                Throwable initCause2 = rnf2.initCause(ex2);
                throw rnf2;
            } catch (Throwable th) {
                Throwable th2 = th;
                if (parser != null) {
                    parser.close();
                }
                throw th2;
            }
        } else if (id == 17563661) {
            FastOutSlowInInterpolator fastOutSlowInInterpolator2 = fastOutSlowInInterpolator;
            FastOutSlowInInterpolator fastOutSlowInInterpolator3 = new FastOutSlowInInterpolator();
            FastOutSlowInInterpolator fastOutSlowInInterpolator4 = fastOutSlowInInterpolator2;
            if (0 != 0) {
                null.close();
            }
            return fastOutSlowInInterpolator4;
        } else if (id == 17563662) {
            LinearOutSlowInInterpolator linearOutSlowInInterpolator2 = linearOutSlowInInterpolator;
            LinearOutSlowInInterpolator linearOutSlowInInterpolator3 = new LinearOutSlowInInterpolator();
            LinearOutSlowInInterpolator linearOutSlowInInterpolator4 = linearOutSlowInInterpolator2;
            if (0 != 0) {
                null.close();
            }
            return linearOutSlowInInterpolator4;
        } else {
            parser = context2.getResources().getAnimation(id);
            Interpolator createInterpolatorFromXml = createInterpolatorFromXml(context2, context2.getResources(), context2.getTheme(), parser);
            if (parser != null) {
                parser.close();
            }
            return createInterpolatorFromXml;
        }
    }

    /* JADX WARNING: type inference failed for: r4v0 */
    /* JADX WARNING: type inference failed for: r4v1 */
    /* JADX WARNING: type inference failed for: r9v6 */
    /* JADX WARNING: type inference failed for: r0v1, types: [android.view.animation.Interpolator] */
    /* JADX WARNING: type inference failed for: r4v2 */
    /* JADX WARNING: type inference failed for: r14v3 */
    /* JADX WARNING: type inference failed for: r9v36 */
    /* JADX WARNING: type inference failed for: r10v15, types: [android.support.graphics.drawable.PathInterpolatorCompat] */
    /* JADX WARNING: type inference failed for: r4v3 */
    /* JADX WARNING: type inference failed for: r14v4 */
    /* JADX WARNING: type inference failed for: r9v38 */
    /* JADX WARNING: type inference failed for: r10v16, types: [android.view.animation.BounceInterpolator] */
    /* JADX WARNING: type inference failed for: r4v4 */
    /* JADX WARNING: type inference failed for: r14v5 */
    /* JADX WARNING: type inference failed for: r9v40 */
    /* JADX WARNING: type inference failed for: r10v17, types: [android.view.animation.AnticipateOvershootInterpolator] */
    /* JADX WARNING: type inference failed for: r4v5 */
    /* JADX WARNING: type inference failed for: r14v6 */
    /* JADX WARNING: type inference failed for: r9v42 */
    /* JADX WARNING: type inference failed for: r10v18, types: [android.view.animation.OvershootInterpolator] */
    /* JADX WARNING: type inference failed for: r4v6 */
    /* JADX WARNING: type inference failed for: r14v7 */
    /* JADX WARNING: type inference failed for: r9v44 */
    /* JADX WARNING: type inference failed for: r10v19, types: [android.view.animation.AnticipateInterpolator] */
    /* JADX WARNING: type inference failed for: r4v7 */
    /* JADX WARNING: type inference failed for: r14v8 */
    /* JADX WARNING: type inference failed for: r9v46 */
    /* JADX WARNING: type inference failed for: r10v20, types: [android.view.animation.CycleInterpolator] */
    /* JADX WARNING: type inference failed for: r4v8 */
    /* JADX WARNING: type inference failed for: r14v9 */
    /* JADX WARNING: type inference failed for: r9v48 */
    /* JADX WARNING: type inference failed for: r10v21, types: [android.view.animation.AccelerateDecelerateInterpolator] */
    /* JADX WARNING: type inference failed for: r4v9 */
    /* JADX WARNING: type inference failed for: r14v10 */
    /* JADX WARNING: type inference failed for: r9v50 */
    /* JADX WARNING: type inference failed for: r10v22, types: [android.view.animation.DecelerateInterpolator] */
    /* JADX WARNING: type inference failed for: r4v10 */
    /* JADX WARNING: type inference failed for: r14v11 */
    /* JADX WARNING: type inference failed for: r9v52 */
    /* JADX WARNING: type inference failed for: r10v23, types: [android.view.animation.AccelerateInterpolator] */
    /* JADX WARNING: type inference failed for: r4v11 */
    /* JADX WARNING: type inference failed for: r14v12 */
    /* JADX WARNING: type inference failed for: r9v54 */
    /* JADX WARNING: type inference failed for: r10v24, types: [android.view.animation.LinearInterpolator] */
    /* JADX WARNING: type inference failed for: r4v12 */
    /* JADX WARNING: type inference failed for: r4v13 */
    /* JADX WARNING: type inference failed for: r4v14 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r4v2
      assigns: []
      uses: []
      mth insns count: 130
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 34 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.view.animation.Interpolator createInterpolatorFromXml(android.content.Context r15, android.content.res.Resources r16, android.content.res.Resources.Theme r17, org.xmlpull.v1.XmlPullParser r18) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            r0 = r15
            r1 = r16
            r2 = r17
            r3 = r18
            r9 = 0
            r4 = r9
            r9 = r3
            int r9 = r9.getDepth()
            r6 = r9
        L_0x000f:
            r9 = r3
            int r9 = r9.next()
            r14 = r9
            r9 = r14
            r10 = r14
            r5 = r10
            r10 = 3
            if (r9 != r10) goto L_0x0023
            r9 = r3
            int r9 = r9.getDepth()
            r10 = r6
            if (r9 <= r10) goto L_0x0138
        L_0x0023:
            r9 = r5
            r10 = 1
            if (r9 == r10) goto L_0x0138
            r9 = r5
            r10 = 2
            if (r9 == r10) goto L_0x002c
            goto L_0x000f
        L_0x002c:
            r9 = r3
            android.util.AttributeSet r9 = android.util.Xml.asAttributeSet(r9)
            r7 = r9
            r9 = r3
            java.lang.String r9 = r9.getName()
            r8 = r9
            r9 = r8
            java.lang.String r10 = "linearInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x004c
            android.view.animation.LinearInterpolator r9 = new android.view.animation.LinearInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r10.<init>()
            r4 = r9
        L_0x004b:
            goto L_0x000f
        L_0x004c:
            r9 = r8
            java.lang.String r10 = "accelerateInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x0062
            android.view.animation.AccelerateInterpolator r9 = new android.view.animation.AccelerateInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x0062:
            r9 = r8
            java.lang.String r10 = "decelerateInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x0078
            android.view.animation.DecelerateInterpolator r9 = new android.view.animation.DecelerateInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x0078:
            r9 = r8
            java.lang.String r10 = "accelerateDecelerateInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x008c
            android.view.animation.AccelerateDecelerateInterpolator r9 = new android.view.animation.AccelerateDecelerateInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r10.<init>()
            r4 = r9
            goto L_0x004b
        L_0x008c:
            r9 = r8
            java.lang.String r10 = "cycleInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x00a2
            android.view.animation.CycleInterpolator r9 = new android.view.animation.CycleInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x00a2:
            r9 = r8
            java.lang.String r10 = "anticipateInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x00b8
            android.view.animation.AnticipateInterpolator r9 = new android.view.animation.AnticipateInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x00b8:
            r9 = r8
            java.lang.String r10 = "overshootInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x00cf
            android.view.animation.OvershootInterpolator r9 = new android.view.animation.OvershootInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x00cf:
            r9 = r8
            java.lang.String r10 = "anticipateOvershootInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x00e6
            android.view.animation.AnticipateOvershootInterpolator r9 = new android.view.animation.AnticipateOvershootInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r10.<init>(r11, r12)
            r4 = r9
            goto L_0x004b
        L_0x00e6:
            r9 = r8
            java.lang.String r10 = "bounceInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x00fb
            android.view.animation.BounceInterpolator r9 = new android.view.animation.BounceInterpolator
            r14 = r9
            r9 = r14
            r10 = r14
            r10.<init>()
            r4 = r9
            goto L_0x004b
        L_0x00fb:
            r9 = r8
            java.lang.String r10 = "pathInterpolator"
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x0113
            android.support.graphics.drawable.PathInterpolatorCompat r9 = new android.support.graphics.drawable.PathInterpolatorCompat
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            r12 = r7
            r13 = r3
            r10.<init>(r11, r12, r13)
            r4 = r9
            goto L_0x004b
        L_0x0113:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException
            r14 = r9
            r9 = r14
            r10 = r14
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r14 = r11
            r11 = r14
            r12 = r14
            r12.<init>()
            java.lang.String r12 = "Unknown interpolator name: "
            java.lang.StringBuilder r11 = r11.append(r12)
            r12 = r3
            java.lang.String r12 = r12.getName()
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r11 = r11.toString()
            r10.<init>(r11)
            throw r9
        L_0x0138:
            r9 = r4
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.AnimationUtilsCompat.createInterpolatorFromXml(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser):android.view.animation.Interpolator");
    }

    private AnimationUtilsCompat() {
    }
}
