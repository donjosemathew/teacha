package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.graphics.drawable.Animatable2Compat.AnimationCallback;
import android.support.p000v4.content.res.ResourcesCompat;
import android.support.p000v4.content.res.TypedArrayUtils;
import android.support.p000v4.graphics.drawable.DrawableCompat;
import android.support.p000v4.util.C1307ArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class AnimatedVectorDrawableCompat extends VectorDrawableCommon implements Animatable2Compat {
    private static final String ANIMATED_VECTOR = "animated-vector";
    private static final boolean DBG_ANIMATION_VECTOR_DRAWABLE = false;
    private static final String LOGTAG = "AnimatedVDCompat";
    private static final String TARGET = "target";
    private AnimatedVectorDrawableCompatState mAnimatedVectorState;
    ArrayList<AnimationCallback> mAnimationCallbacks;
    private AnimatorListener mAnimatorListener;
    private ArgbEvaluator mArgbEvaluator;
    AnimatedVectorDrawableDelegateState mCachedConstantStateDelegate;
    final Callback mCallback;
    private Context mContext;

    private static class AnimatedVectorDrawableCompatState extends ConstantState {
        AnimatorSet mAnimatorSet;
        ArrayList<Animator> mAnimators;
        int mChangingConfigurations;
        C1307ArrayMap<Animator, String> mTargetNameMap;
        VectorDrawableCompat mVectorDrawable;

        public AnimatedVectorDrawableCompatState(Context context, AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState, Callback callback, Resources resources) {
            ArrayList<Animator> arrayList;
            C1307ArrayMap<Animator, String> arrayMap;
            Context context2 = context;
            AnimatedVectorDrawableCompatState copy = animatedVectorDrawableCompatState;
            Callback owner = callback;
            Resources res = resources;
            if (copy != null) {
                this.mChangingConfigurations = copy.mChangingConfigurations;
                if (copy.mVectorDrawable != null) {
                    ConstantState cs = copy.mVectorDrawable.getConstantState();
                    if (res != null) {
                        this.mVectorDrawable = (VectorDrawableCompat) cs.newDrawable(res);
                    } else {
                        this.mVectorDrawable = (VectorDrawableCompat) cs.newDrawable();
                    }
                    this.mVectorDrawable = (VectorDrawableCompat) this.mVectorDrawable.mutate();
                    this.mVectorDrawable.setCallback(owner);
                    this.mVectorDrawable.setBounds(copy.mVectorDrawable.getBounds());
                    this.mVectorDrawable.setAllowCaching(false);
                }
                if (copy.mAnimators != null) {
                    int numAnimators = copy.mAnimators.size();
                    ArrayList<Animator> arrayList2 = arrayList;
                    ArrayList<Animator> arrayList3 = new ArrayList<>(numAnimators);
                    this.mAnimators = arrayList2;
                    C1307ArrayMap<Animator, String> arrayMap2 = arrayMap;
                    C1307ArrayMap<Animator, String> arrayMap3 = new C1307ArrayMap<>(numAnimators);
                    this.mTargetNameMap = arrayMap2;
                    for (int i = 0; i < numAnimators; i++) {
                        Animator anim = (Animator) copy.mAnimators.get(i);
                        Animator animClone = anim.clone();
                        String targetName = (String) copy.mTargetNameMap.get(anim);
                        animClone.setTarget(this.mVectorDrawable.getTargetByName(targetName));
                        boolean add = this.mAnimators.add(animClone);
                        Object put = this.mTargetNameMap.put(animClone, targetName);
                    }
                    setupAnimatorSet();
                }
            }
        }

        public Drawable newDrawable() {
            IllegalStateException illegalStateException;
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("No constant state support for SDK < 24.");
            throw illegalStateException2;
        }

        public Drawable newDrawable(Resources resources) {
            IllegalStateException illegalStateException;
            Resources resources2 = resources;
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("No constant state support for SDK < 24.");
            throw illegalStateException2;
        }

        public int getChangingConfigurations() {
            return this.mChangingConfigurations;
        }

        public void setupAnimatorSet() {
            AnimatorSet animatorSet;
            if (this.mAnimatorSet == null) {
                AnimatorSet animatorSet2 = animatorSet;
                AnimatorSet animatorSet3 = new AnimatorSet();
                this.mAnimatorSet = animatorSet2;
            }
            this.mAnimatorSet.playTogether(this.mAnimators);
        }
    }

    @RequiresApi(24)
    private static class AnimatedVectorDrawableDelegateState extends ConstantState {
        private final ConstantState mDelegateState;

        public AnimatedVectorDrawableDelegateState(ConstantState constantState) {
            this.mDelegateState = constantState;
        }

        public Drawable newDrawable() {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat2 = animatedVectorDrawableCompat;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat3 = new AnimatedVectorDrawableCompat();
            AnimatedVectorDrawableCompat drawableCompat = animatedVectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = this.mDelegateState.newDrawable();
            drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
            return drawableCompat;
        }

        public Drawable newDrawable(Resources resources) {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
            Resources res = resources;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat2 = animatedVectorDrawableCompat;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat3 = new AnimatedVectorDrawableCompat();
            AnimatedVectorDrawableCompat drawableCompat = animatedVectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = this.mDelegateState.newDrawable(res);
            drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
            return drawableCompat;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
            Resources res = resources;
            Theme theme2 = theme;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat2 = animatedVectorDrawableCompat;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat3 = new AnimatedVectorDrawableCompat();
            AnimatedVectorDrawableCompat drawableCompat = animatedVectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = this.mDelegateState.newDrawable(res, theme2);
            drawableCompat.mDelegateDrawable.setCallback(drawableCompat.mCallback);
            return drawableCompat;
        }

        public boolean canApplyTheme() {
            return this.mDelegateState.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.mDelegateState.getChangingConfigurations();
        }
    }

    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
        return super.getColorFilter();
    }

    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    public /* bridge */ /* synthetic */ void setColorFilter(int i, Mode mode) {
        super.setColorFilter(i, mode);
    }

    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    AnimatedVectorDrawableCompat() {
        this(null, null, null);
    }

    private AnimatedVectorDrawableCompat(@Nullable Context context) {
        this(context, null, null);
    }

    private AnimatedVectorDrawableCompat(@Nullable Context context, @Nullable AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState, @Nullable Resources resources) {
        C01601 r11;
        AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState2;
        Context context2 = context;
        AnimatedVectorDrawableCompatState state = animatedVectorDrawableCompatState;
        Resources res = resources;
        this.mArgbEvaluator = null;
        this.mAnimatorListener = null;
        this.mAnimationCallbacks = null;
        C01601 r5 = r11;
        C01601 r6 = new Callback(this) {
            final /* synthetic */ AnimatedVectorDrawableCompat this$0;

            {
                this.this$0 = r5;
            }

            public void invalidateDrawable(Drawable drawable) {
                Drawable drawable2 = drawable;
                this.this$0.invalidateSelf();
            }

            public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
                Drawable drawable2 = drawable;
                Runnable what = runnable;
                long when = j;
                this.this$0.scheduleSelf(what, when);
            }

            public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
                Drawable drawable2 = drawable;
                Runnable what = runnable;
                this.this$0.unscheduleSelf(what);
            }
        };
        this.mCallback = r5;
        this.mContext = context2;
        if (state != null) {
            this.mAnimatedVectorState = state;
            return;
        }
        AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState3 = animatedVectorDrawableCompatState2;
        AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState4 = new AnimatedVectorDrawableCompatState(context2, state, this.mCallback, res);
        this.mAnimatedVectorState = animatedVectorDrawableCompatState3;
    }

    public Drawable mutate() {
        if (this.mDelegateDrawable != null) {
            Drawable mutate = this.mDelegateDrawable.mutate();
        }
        return this;
    }

    @Nullable
    public static AnimatedVectorDrawableCompat create(@NonNull Context context, @DrawableRes int i) {
        int type;
        XmlPullParserException xmlPullParserException;
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
        AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState;
        Context context2 = context;
        int resId = i;
        if (VERSION.SDK_INT >= 24) {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat2 = animatedVectorDrawableCompat;
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat3 = new AnimatedVectorDrawableCompat(context2);
            AnimatedVectorDrawableCompat drawable = animatedVectorDrawableCompat2;
            drawable.mDelegateDrawable = ResourcesCompat.getDrawable(context2.getResources(), resId, context2.getTheme());
            drawable.mDelegateDrawable.setCallback(drawable.mCallback);
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat4 = drawable;
            AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState2 = animatedVectorDrawableDelegateState;
            AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState3 = new AnimatedVectorDrawableDelegateState(drawable.mDelegateDrawable.getConstantState());
            animatedVectorDrawableCompat4.mCachedConstantStateDelegate = animatedVectorDrawableDelegateState2;
            return drawable;
        }
        try {
            XmlResourceParser xml = context2.getResources().getXml(resId);
            AttributeSet attrs = Xml.asAttributeSet(xml);
            while (true) {
                int next = xml.next();
                type = next;
                if (next == 2 || type == 1) {
                }
            }
            if (type != 2) {
                XmlPullParserException xmlPullParserException2 = xmlPullParserException;
                XmlPullParserException xmlPullParserException3 = new XmlPullParserException("No start tag found");
                throw xmlPullParserException2;
            }
            return createFromXmlInner(context2, context2.getResources(), xml, attrs, context2.getTheme());
        } catch (XmlPullParserException e) {
            int e2 = Log.e(LOGTAG, "parser error", e);
            return null;
        } catch (IOException e3) {
            int e4 = Log.e(LOGTAG, "parser error", e3);
            return null;
        }
    }

    public static AnimatedVectorDrawableCompat createFromXmlInner(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
        Resources r = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        Theme theme2 = theme;
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat2 = animatedVectorDrawableCompat;
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat3 = new AnimatedVectorDrawableCompat(context);
        AnimatedVectorDrawableCompat drawable = animatedVectorDrawableCompat2;
        drawable.inflate(r, parser, attrs, theme2);
        return drawable;
    }

    public ConstantState getConstantState() {
        AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState;
        if (this.mDelegateDrawable == null || VERSION.SDK_INT < 24) {
            return null;
        }
        AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState2 = animatedVectorDrawableDelegateState;
        AnimatedVectorDrawableDelegateState animatedVectorDrawableDelegateState3 = new AnimatedVectorDrawableDelegateState(this.mDelegateDrawable.getConstantState());
        return animatedVectorDrawableDelegateState2;
    }

    public int getChangingConfigurations() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.mAnimatedVectorState.mChangingConfigurations;
    }

    public void draw(Canvas canvas) {
        Canvas canvas2 = canvas;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.draw(canvas2);
            return;
        }
        this.mAnimatedVectorState.mVectorDrawable.draw(canvas2);
        if (this.mAnimatedVectorState.mAnimatorSet.isStarted()) {
            invalidateSelf();
        }
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        Rect bounds = rect;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setBounds(bounds);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setBounds(bounds);
        }
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        int[] state = iArr;
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.setState(state);
        }
        return this.mAnimatedVectorState.mVectorDrawable.setState(state);
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i) {
        int level = i;
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.setLevel(level);
        }
        return this.mAnimatedVectorState.mVectorDrawable.setLevel(level);
    }

    public int getAlpha() {
        if (this.mDelegateDrawable != null) {
            return DrawableCompat.getAlpha(this.mDelegateDrawable);
        }
        return this.mAnimatedVectorState.mVectorDrawable.getAlpha();
    }

    public void setAlpha(int i) {
        int alpha = i;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setAlpha(alpha);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setAlpha(alpha);
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        ColorFilter colorFilter2 = colorFilter;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setColorFilter(colorFilter2);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setColorFilter(colorFilter2);
        }
    }

    public void setTint(int i) {
        int tint = i;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTint(this.mDelegateDrawable, tint);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setTint(tint);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        ColorStateList tint = colorStateList;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTintList(this.mDelegateDrawable, tint);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setTintList(tint);
        }
    }

    public void setTintMode(Mode mode) {
        Mode tintMode = mode;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTintMode(this.mDelegateDrawable, tintMode);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setTintMode(tintMode);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = z;
        boolean restart = z2;
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.setVisible(visible, restart);
        }
        boolean visible2 = this.mAnimatedVectorState.mVectorDrawable.setVisible(visible, restart);
        return super.setVisible(visible, restart);
    }

    public boolean isStateful() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.isStateful();
        }
        return this.mAnimatedVectorState.mVectorDrawable.isStateful();
    }

    public int getOpacity() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getOpacity();
        }
        return this.mAnimatedVectorState.mVectorDrawable.getOpacity();
    }

    public int getIntrinsicWidth() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getIntrinsicWidth();
        }
        return this.mAnimatedVectorState.mVectorDrawable.getIntrinsicWidth();
    }

    public int getIntrinsicHeight() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getIntrinsicHeight();
        }
        return this.mAnimatedVectorState.mVectorDrawable.getIntrinsicHeight();
    }

    public boolean isAutoMirrored() {
        if (this.mDelegateDrawable != null) {
            return DrawableCompat.isAutoMirrored(this.mDelegateDrawable);
        }
        return this.mAnimatedVectorState.mVectorDrawable.isAutoMirrored();
    }

    public void setAutoMirrored(boolean z) {
        boolean mirrored = z;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setAutoMirrored(this.mDelegateDrawable, mirrored);
        } else {
            this.mAnimatedVectorState.mVectorDrawable.setAutoMirrored(mirrored);
        }
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        IllegalStateException illegalStateException;
        Resources res = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        Theme theme2 = theme;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.inflate(this.mDelegateDrawable, res, parser, attrs, theme2);
            return;
        }
        int eventType = parser.getEventType();
        int innerDepth = parser.getDepth() + 1;
        while (eventType != 1 && (parser.getDepth() >= innerDepth || eventType != 3)) {
            if (eventType == 2) {
                String tagName = parser.getName();
                if (ANIMATED_VECTOR.equals(tagName)) {
                    TypedArray a = TypedArrayUtils.obtainAttributes(res, theme2, attrs, AndroidResources.STYLEABLE_ANIMATED_VECTOR_DRAWABLE);
                    int drawableRes = a.getResourceId(0, 0);
                    if (drawableRes != 0) {
                        VectorDrawableCompat vectorDrawable = VectorDrawableCompat.create(res, drawableRes, theme2);
                        vectorDrawable.setAllowCaching(false);
                        vectorDrawable.setCallback(this.mCallback);
                        if (this.mAnimatedVectorState.mVectorDrawable != null) {
                            this.mAnimatedVectorState.mVectorDrawable.setCallback(null);
                        }
                        this.mAnimatedVectorState.mVectorDrawable = vectorDrawable;
                    }
                    a.recycle();
                } else if (TARGET.equals(tagName)) {
                    TypedArray a2 = res.obtainAttributes(attrs, AndroidResources.STYLEABLE_ANIMATED_VECTOR_DRAWABLE_TARGET);
                    String target = a2.getString(0);
                    int id = a2.getResourceId(1, 0);
                    if (id != 0) {
                        if (this.mContext != null) {
                            setupAnimatorsForTarget(target, AnimatorInflaterCompat.loadAnimator(this.mContext, id));
                        } else {
                            a2.recycle();
                            IllegalStateException illegalStateException2 = illegalStateException;
                            IllegalStateException illegalStateException3 = new IllegalStateException("Context can't be null when inflating animators");
                            throw illegalStateException2;
                        }
                    }
                    a2.recycle();
                } else {
                    continue;
                }
            }
            eventType = parser.next();
        }
        this.mAnimatedVectorState.setupAnimatorSet();
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    public void applyTheme(Theme theme) {
        Theme t = theme;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.applyTheme(this.mDelegateDrawable, t);
        }
    }

    public boolean canApplyTheme() {
        if (this.mDelegateDrawable != null) {
            return DrawableCompat.canApplyTheme(this.mDelegateDrawable);
        }
        return false;
    }

    private void setupColorAnimator(Animator animator) {
        ArgbEvaluator argbEvaluator;
        Animator animator2 = animator;
        if (animator2 instanceof AnimatorSet) {
            ArrayList childAnimations = ((AnimatorSet) animator2).getChildAnimations();
            if (childAnimations != null) {
                for (int i = 0; i < childAnimations.size(); i++) {
                    setupColorAnimator((Animator) childAnimations.get(i));
                }
            }
        }
        if (animator2 instanceof ObjectAnimator) {
            ObjectAnimator objectAnim = (ObjectAnimator) animator2;
            String propertyName = objectAnim.getPropertyName();
            if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
                if (this.mArgbEvaluator == null) {
                    ArgbEvaluator argbEvaluator2 = argbEvaluator;
                    ArgbEvaluator argbEvaluator3 = new ArgbEvaluator();
                    this.mArgbEvaluator = argbEvaluator2;
                }
                objectAnim.setEvaluator(this.mArgbEvaluator);
            }
        }
    }

    private void setupAnimatorsForTarget(String str, Animator animator) {
        ArrayList<Animator> arrayList;
        C1307ArrayMap<Animator, String> arrayMap;
        String name = str;
        Animator animator2 = animator;
        animator2.setTarget(this.mAnimatedVectorState.mVectorDrawable.getTargetByName(name));
        if (VERSION.SDK_INT < 21) {
            setupColorAnimator(animator2);
        }
        if (this.mAnimatedVectorState.mAnimators == null) {
            AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState = this.mAnimatedVectorState;
            ArrayList<Animator> arrayList2 = arrayList;
            ArrayList<Animator> arrayList3 = new ArrayList<>();
            animatedVectorDrawableCompatState.mAnimators = arrayList2;
            AnimatedVectorDrawableCompatState animatedVectorDrawableCompatState2 = this.mAnimatedVectorState;
            C1307ArrayMap<Animator, String> arrayMap2 = arrayMap;
            C1307ArrayMap<Animator, String> arrayMap3 = new C1307ArrayMap<>();
            animatedVectorDrawableCompatState2.mTargetNameMap = arrayMap2;
        }
        boolean add = this.mAnimatedVectorState.mAnimators.add(animator2);
        Object put = this.mAnimatedVectorState.mTargetNameMap.put(animator2, name);
    }

    public boolean isRunning() {
        if (this.mDelegateDrawable != null) {
            return ((AnimatedVectorDrawable) this.mDelegateDrawable).isRunning();
        }
        return this.mAnimatedVectorState.mAnimatorSet.isRunning();
    }

    public void start() {
        if (this.mDelegateDrawable != null) {
            ((AnimatedVectorDrawable) this.mDelegateDrawable).start();
        } else if (!this.mAnimatedVectorState.mAnimatorSet.isStarted()) {
            this.mAnimatedVectorState.mAnimatorSet.start();
            invalidateSelf();
        }
    }

    public void stop() {
        if (this.mDelegateDrawable != null) {
            ((AnimatedVectorDrawable) this.mDelegateDrawable).stop();
        } else {
            this.mAnimatedVectorState.mAnimatorSet.end();
        }
    }

    @RequiresApi(23)
    private static boolean unregisterPlatformCallback(AnimatedVectorDrawable animatedVectorDrawable, AnimationCallback animationCallback) {
        return animatedVectorDrawable.unregisterAnimationCallback(animationCallback.getPlatformCallback());
    }

    public void registerAnimationCallback(@NonNull AnimationCallback animationCallback) {
        C01612 r6;
        ArrayList<AnimationCallback> arrayList;
        AnimationCallback callback = animationCallback;
        if (this.mDelegateDrawable != null) {
            registerPlatformCallback((AnimatedVectorDrawable) this.mDelegateDrawable, callback);
        } else if (callback != null) {
            if (this.mAnimationCallbacks == null) {
                ArrayList<AnimationCallback> arrayList2 = arrayList;
                ArrayList<AnimationCallback> arrayList3 = new ArrayList<>();
                this.mAnimationCallbacks = arrayList2;
            }
            if (!this.mAnimationCallbacks.contains(callback)) {
                boolean add = this.mAnimationCallbacks.add(callback);
                if (this.mAnimatorListener == null) {
                    C01612 r3 = r6;
                    C01612 r4 = new AnimatorListenerAdapter(this) {
                        final /* synthetic */ AnimatedVectorDrawableCompat this$0;

                        {
                            this.this$0 = r5;
                        }

                        public void onAnimationStart(Animator animator) {
                            ArrayList arrayList;
                            Animator animator2 = animator;
                            ArrayList arrayList2 = arrayList;
                            ArrayList arrayList3 = new ArrayList(this.this$0.mAnimationCallbacks);
                            ArrayList arrayList4 = arrayList2;
                            int size = arrayList4.size();
                            for (int i = 0; i < size; i++) {
                                ((AnimationCallback) arrayList4.get(i)).onAnimationStart(this.this$0);
                            }
                        }

                        public void onAnimationEnd(Animator animator) {
                            ArrayList arrayList;
                            Animator animator2 = animator;
                            ArrayList arrayList2 = arrayList;
                            ArrayList arrayList3 = new ArrayList(this.this$0.mAnimationCallbacks);
                            ArrayList arrayList4 = arrayList2;
                            int size = arrayList4.size();
                            for (int i = 0; i < size; i++) {
                                ((AnimationCallback) arrayList4.get(i)).onAnimationEnd(this.this$0);
                            }
                        }
                    };
                    this.mAnimatorListener = r3;
                }
                this.mAnimatedVectorState.mAnimatorSet.addListener(this.mAnimatorListener);
            }
        }
    }

    @RequiresApi(23)
    private static void registerPlatformCallback(@NonNull AnimatedVectorDrawable animatedVectorDrawable, @NonNull AnimationCallback animationCallback) {
        animatedVectorDrawable.registerAnimationCallback(animationCallback.getPlatformCallback());
    }

    private void removeAnimatorSetListener() {
        if (this.mAnimatorListener != null) {
            this.mAnimatedVectorState.mAnimatorSet.removeListener(this.mAnimatorListener);
            this.mAnimatorListener = null;
        }
    }

    public boolean unregisterAnimationCallback(@NonNull AnimationCallback animationCallback) {
        AnimationCallback callback = animationCallback;
        if (this.mDelegateDrawable != null) {
            boolean unregisterPlatformCallback = unregisterPlatformCallback((AnimatedVectorDrawable) this.mDelegateDrawable, callback);
        }
        if (this.mAnimationCallbacks == null || callback == null) {
            return false;
        }
        boolean removed = this.mAnimationCallbacks.remove(callback);
        if (this.mAnimationCallbacks.size() == 0) {
            removeAnimatorSetListener();
        }
        return removed;
    }

    public void clearAnimationCallbacks() {
        if (this.mDelegateDrawable != null) {
            ((AnimatedVectorDrawable) this.mDelegateDrawable).clearAnimationCallbacks();
            return;
        }
        removeAnimatorSetListener();
        if (this.mAnimationCallbacks != null) {
            this.mAnimationCallbacks.clear();
        }
    }

    public static void registerAnimationCallback(Drawable drawable, AnimationCallback animationCallback) {
        Drawable dr = drawable;
        AnimationCallback callback = animationCallback;
        if (dr != null && callback != null && (dr instanceof Animatable)) {
            if (VERSION.SDK_INT >= 24) {
                registerPlatformCallback((AnimatedVectorDrawable) dr, callback);
            } else {
                ((AnimatedVectorDrawableCompat) dr).registerAnimationCallback(callback);
            }
        }
    }

    public static boolean unregisterAnimationCallback(Drawable drawable, AnimationCallback animationCallback) {
        Drawable dr = drawable;
        AnimationCallback callback = animationCallback;
        if (dr == null || callback == null) {
            return false;
        }
        if (!(dr instanceof Animatable)) {
            return false;
        }
        if (VERSION.SDK_INT >= 24) {
            return unregisterPlatformCallback((AnimatedVectorDrawable) dr, callback);
        }
        return ((AnimatedVectorDrawableCompat) dr).unregisterAnimationCallback(callback);
    }

    public static void clearAnimationCallbacks(Drawable drawable) {
        Drawable dr = drawable;
        if (dr != null && (dr instanceof Animatable)) {
            if (VERSION.SDK_INT >= 24) {
                ((AnimatedVectorDrawable) dr).clearAnimationCallbacks();
            } else {
                ((AnimatedVectorDrawableCompat) dr).clearAnimationCallbacks();
            }
        }
    }
}
