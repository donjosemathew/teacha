package android.support.customtabs;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.customtabs.ICustomTabsCallback.Stub;
import android.support.p000v4.app.BundleCompat;
import android.util.Log;

public class CustomTabsSessionToken {
    private static final String TAG = "CustomTabsSessionToken";
    private final CustomTabsCallback mCallback;
    final ICustomTabsCallback mCallbackBinder;

    static class MockCallback extends Stub {
        MockCallback() {
        }

        public void onNavigationEvent(int navigationEvent, Bundle extras) {
        }

        public void extraCallback(String callbackName, Bundle args) {
        }

        public void onMessageChannelReady(Bundle extras) {
        }

        public void onPostMessage(String message, Bundle extras) {
        }

        public void onRelationshipValidationResult(int relation, Uri requestedOrigin, boolean result, Bundle extras) {
        }

        public IBinder asBinder() {
            return this;
        }
    }

    public static CustomTabsSessionToken getSessionTokenFromIntent(Intent intent) {
        CustomTabsSessionToken customTabsSessionToken;
        IBinder binder = BundleCompat.getBinder(intent.getExtras(), CustomTabsIntent.EXTRA_SESSION);
        if (binder == null) {
            return null;
        }
        CustomTabsSessionToken customTabsSessionToken2 = customTabsSessionToken;
        CustomTabsSessionToken customTabsSessionToken3 = new CustomTabsSessionToken(Stub.asInterface(binder));
        return customTabsSessionToken2;
    }

    @NonNull
    public static CustomTabsSessionToken createMockSessionTokenForTesting() {
        CustomTabsSessionToken customTabsSessionToken;
        MockCallback mockCallback;
        CustomTabsSessionToken customTabsSessionToken2 = customTabsSessionToken;
        MockCallback mockCallback2 = mockCallback;
        MockCallback mockCallback3 = new MockCallback();
        CustomTabsSessionToken customTabsSessionToken3 = new CustomTabsSessionToken(mockCallback2);
        return customTabsSessionToken2;
    }

    CustomTabsSessionToken(ICustomTabsCallback iCustomTabsCallback) {
        C00541 r6;
        this.mCallbackBinder = iCustomTabsCallback;
        C00541 r3 = r6;
        C00541 r4 = new CustomTabsCallback(this) {
            final /* synthetic */ CustomTabsSessionToken this$0;

            {
                this.this$0 = r5;
            }

            public void onNavigationEvent(int i, Bundle bundle) {
                try {
                    this.this$0.mCallbackBinder.onNavigationEvent(i, bundle);
                } catch (RemoteException e) {
                    RemoteException remoteException = e;
                    int e2 = Log.e(CustomTabsSessionToken.TAG, "RemoteException during ICustomTabsCallback transaction");
                }
            }

            public void extraCallback(String str, Bundle bundle) {
                try {
                    this.this$0.mCallbackBinder.extraCallback(str, bundle);
                } catch (RemoteException e) {
                    RemoteException remoteException = e;
                    int e2 = Log.e(CustomTabsSessionToken.TAG, "RemoteException during ICustomTabsCallback transaction");
                }
            }

            public void onMessageChannelReady(Bundle bundle) {
                try {
                    this.this$0.mCallbackBinder.onMessageChannelReady(bundle);
                } catch (RemoteException e) {
                    RemoteException remoteException = e;
                    int e2 = Log.e(CustomTabsSessionToken.TAG, "RemoteException during ICustomTabsCallback transaction");
                }
            }

            public void onPostMessage(String str, Bundle bundle) {
                try {
                    this.this$0.mCallbackBinder.onPostMessage(str, bundle);
                } catch (RemoteException e) {
                    RemoteException remoteException = e;
                    int e2 = Log.e(CustomTabsSessionToken.TAG, "RemoteException during ICustomTabsCallback transaction");
                }
            }

            public void onRelationshipValidationResult(int i, Uri uri, boolean z, Bundle bundle) {
                try {
                    this.this$0.mCallbackBinder.onRelationshipValidationResult(i, uri, z, bundle);
                } catch (RemoteException e) {
                    RemoteException remoteException = e;
                    int e2 = Log.e(CustomTabsSessionToken.TAG, "RemoteException during ICustomTabsCallback transaction");
                }
            }
        };
        this.mCallback = r3;
    }

    /* access modifiers changed from: 0000 */
    public IBinder getCallbackBinder() {
        return this.mCallbackBinder.asBinder();
    }

    public int hashCode() {
        return getCallbackBinder().hashCode();
    }

    public boolean equals(Object obj) {
        Object o = obj;
        if (!(o instanceof CustomTabsSessionToken)) {
            return false;
        }
        return ((CustomTabsSessionToken) o).getCallbackBinder().equals(this.mCallbackBinder.asBinder());
    }

    public CustomTabsCallback getCallback() {
        return this.mCallback;
    }

    public boolean isAssociatedWith(CustomTabsSession customTabsSession) {
        return customTabsSession.getBinder().equals(this.mCallbackBinder);
    }
}
