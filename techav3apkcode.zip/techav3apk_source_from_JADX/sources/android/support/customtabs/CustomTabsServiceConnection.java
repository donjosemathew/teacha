package android.support.customtabs;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.customtabs.ICustomTabsService.Stub;

public abstract class CustomTabsServiceConnection implements ServiceConnection {
    public abstract void onCustomTabsServiceConnected(ComponentName componentName, CustomTabsClient customTabsClient);

    public CustomTabsServiceConnection() {
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        C00531 r10;
        ComponentName name = componentName;
        ComponentName componentName2 = name;
        C00531 r5 = r10;
        C00531 r6 = new CustomTabsClient(this, Stub.asInterface(iBinder), name) {
            final /* synthetic */ CustomTabsServiceConnection this$0;

            {
                ICustomTabsService service = r9;
                ComponentName componentName = r10;
                this.this$0 = r8;
            }
        };
        onCustomTabsServiceConnected(componentName2, r5);
    }
}
