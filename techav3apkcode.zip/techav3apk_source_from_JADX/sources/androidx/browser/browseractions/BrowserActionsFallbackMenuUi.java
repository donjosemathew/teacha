package androidx.browser.browseractions;

import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.net.Uri;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.annotation.VisibleForTesting;
import android.support.customtabs.C0056R;
import android.support.p000v4.widget.TextViewCompat;
import android.text.TextUtils.TruncateAt;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import java.util.List;

class BrowserActionsFallbackMenuUi implements OnItemClickListener {
    private static final String TAG = "BrowserActionskMenuUi";
    private BrowserActionsFallbackMenuDialog mBrowserActionsDialog;
    private final Context mContext;
    private final List<BrowserActionItem> mMenuItems;
    BrowserActionsFallMenuUiListener mMenuUiListener;
    private final Uri mUri;

    @VisibleForTesting
    @RestrictTo({Scope.LIBRARY_GROUP})
    interface BrowserActionsFallMenuUiListener {
        void onMenuShown(View view);
    }

    BrowserActionsFallbackMenuUi(Context context, Uri uri, List<BrowserActionItem> list) {
        Uri uri2 = uri;
        List<BrowserActionItem> menuItems = list;
        this.mContext = context;
        this.mUri = uri2;
        this.mMenuItems = menuItems;
    }

    /* access modifiers changed from: 0000 */
    @VisibleForTesting
    @RestrictTo({Scope.LIBRARY_GROUP})
    public void setMenuUiListener(BrowserActionsFallMenuUiListener browserActionsFallMenuUiListener) {
        BrowserActionsFallMenuUiListener browserActionsFallMenuUiListener2 = browserActionsFallMenuUiListener;
        this.mMenuUiListener = browserActionsFallMenuUiListener2;
    }

    public void displayMenu() {
        BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog;
        C05461 r8;
        View view = LayoutInflater.from(this.mContext).inflate(C0056R.layout.browser_actions_context_menu_page, null);
        BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog2 = browserActionsFallbackMenuDialog;
        BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog3 = new BrowserActionsFallbackMenuDialog(this.mContext, initMenuView(view));
        this.mBrowserActionsDialog = browserActionsFallbackMenuDialog2;
        this.mBrowserActionsDialog.setContentView(view);
        if (this.mMenuUiListener != null) {
            BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog4 = this.mBrowserActionsDialog;
            C05461 r3 = r8;
            final View view2 = view;
            C05461 r4 = new OnShowListener(this) {
                final /* synthetic */ BrowserActionsFallbackMenuUi this$0;

                {
                    View view = r7;
                    this.this$0 = r6;
                }

                public void onShow(DialogInterface dialogInterface) {
                    DialogInterface dialogInterface2 = dialogInterface;
                    this.this$0.mMenuUiListener.onMenuShown(view2);
                }
            };
            browserActionsFallbackMenuDialog4.setOnShowListener(r3);
        }
        this.mBrowserActionsDialog.show();
    }

    private BrowserActionsFallbackMenuView initMenuView(View view) {
        C05472 r11;
        BrowserActionsFallbackMenuAdapter browserActionsFallbackMenuAdapter;
        View view2 = view;
        BrowserActionsFallbackMenuView menuView = (BrowserActionsFallbackMenuView) view2.findViewById(C0056R.C0058id.browser_actions_menu_view);
        TextView urlTextView = (TextView) view2.findViewById(C0056R.C0058id.browser_actions_header_text);
        urlTextView.setText(this.mUri.toString());
        TextView textView = urlTextView;
        C05472 r7 = r11;
        final TextView textView2 = urlTextView;
        C05472 r8 = new OnClickListener(this) {
            final /* synthetic */ BrowserActionsFallbackMenuUi this$0;

            {
                TextView textView = r7;
                this.this$0 = r6;
            }

            public void onClick(View view) {
                View view2 = view;
                if (TextViewCompat.getMaxLines(textView2) == Integer.MAX_VALUE) {
                    textView2.setMaxLines(1);
                    textView2.setEllipsize(TruncateAt.END);
                    return;
                }
                textView2.setMaxLines(ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED);
                textView2.setEllipsize(null);
            }
        };
        textView.setOnClickListener(r7);
        ListView menuListView = (ListView) view2.findViewById(C0056R.C0058id.browser_actions_menu_items);
        BrowserActionsFallbackMenuAdapter browserActionsFallbackMenuAdapter2 = browserActionsFallbackMenuAdapter;
        BrowserActionsFallbackMenuAdapter browserActionsFallbackMenuAdapter3 = new BrowserActionsFallbackMenuAdapter(this.mMenuItems, this.mContext);
        menuListView.setAdapter(browserActionsFallbackMenuAdapter2);
        menuListView.setOnItemClickListener(this);
        return menuView;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        AdapterView<?> adapterView2 = adapterView;
        View view2 = view;
        long j2 = j;
        try {
            ((BrowserActionItem) this.mMenuItems.get(i)).getAction().send();
            this.mBrowserActionsDialog.dismiss();
        } catch (CanceledException e) {
            int e2 = Log.e(TAG, "Failed to send custom item action", e);
        }
    }
}
